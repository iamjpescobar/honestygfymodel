import streamlit as st
import pandas as pd
from datetime import datetime
from zoneinfo import ZoneInfo

EASTERN = ZoneInfo("America/New_York")

from styles.kc_theme import (
    badge, card, footer, COLOR,
    pitch_color, pitch_name, edge_tag
)
from styles.table_style import (style_stat_table, plain_dark_table,
                                render_html_table, score_bar, bats_chip,
                                tier_legend, style_vs_league, stat_formats,
                                grade_text_column)

from engines.weather_engine import get_todays_games_with_weather
from engines.park_factors import get_park_factor
from engines.pitch_matchup import batter_pitch_profile as _batter_pitch_profile
from engines.headshots import get_headshot_url
from engines.roster import (get_live_team_roster, get_active_player_ids,
                            get_all_teams, get_confirmed_lineup,
                            get_last_starting_lineup, get_recent_activations,
                            prefetch_slate)
from engines.statcast_engine import (
    get_pitcher_statcast, get_pitcher_advanced_splits, get_batter_profile_windowed, get_batter_vs_pitch_types,
    get_first_pitch_swing
, get_batter_iso_vs_hand, hand_tag, get_pitcher_hand
)
from engines import lineup_lock
from engines.savant_leaderboard import load_percentile_ranks
from engines.live_sync import sync_latest_button
from engines.batter_trends import render_batter_trend
from engines.bvp import (render_bvp_card, render_zone_map, render_spray_chart,
                         career_bvp_short, prefetch_career_bvp)
from engines.edge import edge_components, pen_context, bvp_component
from engines.pick_badges import compute_badges, render_badge_row
from engines.pitcher_weakspots import get_weak_spots, XSLG_HOT, XSLG_COLD
from engines.weakspot_view import slot_rows
from engines.board_ranks import board_ranks, token_text
from engines.team_logos import logo_for
from engines.weather_icons import (
    weather_icon, wind_arrow, temp_icon, park_icon,
)
from engines.park_weather import get_park_forecast
from engines.slam_engine import slam_from_profile
from engines.top_plays import rank_batters, confidence_tier, matchup_tier
# THE FORM COMPONENT. One definition of what Form is and how it looks,
# imported rather than re-implemented — the columns, the window it is
# measured over, and the card renderer all come from here, so a change
# to the measurement reaches every board that shows it.
from engines import form as form_engine
from engines.team_abbreviations import team_abbr
from engines.matchup_grades import grade_matchup
from engines.matchup_grades_intl import render_matchup_grades_card
from engines import mlb_game_model as _mlb_game_model
from engines import model_view as _model_view

# page_icon repeated on purpose: set_page_config RE-APPLIES on every
# call, and omitting it here dropped the favicon app.py set, so the
# tab icon vanished on this page only.
st.set_page_config(page_title="Game Card", page_icon="⚾", layout="wide")
# Theme injection lives in app.py, which renders once per script run
# before this view is exec'd. It used to be called here as well, so the
# same ~26KB of inline CSS was serialised, shipped and parsed TWICE on
# every rerun of every page. Same cascade either way (the two layers
# overlap only on properties resolved by specificity), so the second
# copy bought nothing.

games, games_error = get_todays_games_with_weather()

if games_error:
    st.error(f"Couldn't load today's schedule: {games_error}")
    st.stop()

if not games:
    st.info("No MLB games on today's schedule \u2014 likely an off-day or the All-Star break. The slate returns here automatically on the next game day.")
    st.stop()

# ---------------------------------------------------------
# LAYOUT — full-width content. The old in-page right sidebar
# (account card + Matchup/Lineups/... view radio + Glossary) is gone:
# navigation and the Glossary now live in the single unified right
# sidebar rendered by app.py. Only the Matchup view was ever live —
# the other views were "coming soon" placeholders and will return as
# real pages once they're built.
# ---------------------------------------------------------
view = "\U0001F3E0 Matchup"
LIVE_VIEWS = {"\U0001F3E0 Matchup"}

# -----------------------------------------------------
# WORDMARK — spans full width, anchors brand identity without
# eating into the game carousel's fixed height (a text mark, not an
# image, since there's no logo asset to work from yet)
# -----------------------------------------------------
st.markdown(
    f'<div style="display:flex; align-items:center; gap:8px; margin-bottom:var(--lc-space-sm);">'
    f'<span style="font-size:var(--lc-text-title); font-weight:800; letter-spacing:-0.02em; color:{COLOR["text"]};">LOS</span>'
    f'<span style="font-size:var(--lc-text-title); font-weight:800; letter-spacing:-0.02em; color:{COLOR["stat_high"]};">CAPPERS</span>'
    f'</div>',
    unsafe_allow_html=True,
)


# RETURNING-BAT FLOORS — MEASURED 2026-08-19.
#
# A bat activated off the IL cannot appear in the projected lineup,
# because that pool is last game's nine intersected with the active
# roster and an intersection only removes names. These two numbers
# decide which returning bats get added back (see
# _resolve_lineup_batters).
#
# il_return_probe.py, 60 days, 290 usable returns:
#
#   PA/game     started that day      n
#   0-1.5             15.0%          20
#   1.5-2.5           32.7%          55
#   2.5-3.0           44.6%          65
#   3.0-3.5           56.1%          57
#   3.5+              81.7%          93
#
# Monotonic across a 66.7-point spread, so PA-PER-GAME IS THE
# DISCRIMINATOR — the load-bearing assumption behind this floor held up.
#
# WHY 2.5 AND NOT THE 3.0 THIS SHIPPED WITH. The probe prints the trade
# at each cut. 3.0 showed 150 bats at 72.0% and HID 50 who started; 2.5
# shows 215 at 63.7% and hides 21. The two errors are not equal — a
# returning regular the page hides is the exact failure this feature was
# built to fix, while a bat shown who sits is clutter next to a caption
# that already says he might. Trading 8 points of precision to recover
# 29 of 50 hidden starters is the right side of that.
#
# Not lower: 2.0 recovers only 13 more and drops precision to 58.8%,
# which is inside touching distance of the 54.5% base rate — a floor
# that barely beats no floor is not worth having.
#
# 40 PA is UNCHANGED and is still reasoned, not measured. It is a floor
# on the SAMPLE, not on skill: below it a row is mostly blank cells, and
# blank means NOT MEASURED on this board. Sub-floor bats are still named
# in the held-back caption, so nobody disappears.
#
# RE-MEASURE PERIODICALLY — standing rule 1. Re-run the probe every few
# weeks and reset from its section 3.
_RET_MIN_PA = 40
_RET_MIN_PA_PER_GAME = 2.5

# WHAT A RETURNING BAT ACTUALLY IS: A COIN FLIP THAT LEANS.
#
# Measured over the same 290 returns, only 54.5% of activated bats
# started that day, and 63.7% of the ones clearing the floor above. That
# is NOT a projected starter, and these rows must not sit in the table
# looking like the eight around them that came off a real posted lineup.
#
# 63.7% lands inside engines/lineup_lock's own FLUX band (0.34-0.66),
# whose label is "In question" — so the site already had the right
# vocabulary for this and it is reused rather than reinvented.
#
# The single most useful check on this: O'Neil Cruz, 286 PA, 4.4 PA per
# game, activated off the 60-day IL — and he DID NOT START that day. The
# bat that motivated this entire feature is itself an example of why the
# row has to be labelled rather than assumed.
_RET_START_RATE = 0.637

# ---------------------------------------------------------------------
# ONE WINDOW SETTING, SEVERAL PLACES TO CHANGE IT.
#
# The Window control lived only above the batting-order table, at the
# top of a very long card. Every table below it obeys that setting —
# Vs Top 3 Pitches most of all — so reading one of them at a different
# window meant scrolling back up, changing it, and scrolling down again
# to find your place. On a phone that is most of a minute, every time.
#
# The fix is NOT a second independent control. Two Window pickers that
# can disagree is worse than one that is far away: you would read a
# table under a setting the rest of the card is not using and have no
# way to tell. So there is exactly one VALUE
# (st.session_state["lineup_window_value"]) and any number of widgets
# that read and write it.
#
# HOW THE TWO-WAY SYNC WORKS, because Streamlit makes this subtle:
# each widget owns a distinct key (Streamlit forbids sharing one), and
# a widget key that already exists in session_state IGNORES the index=
# argument. So changing the top control would leave the bottom one
# rendering its own stale value. Writing the canonical value into every
# widget's key BEFORE instantiating it is what keeps them honest — that
# assignment is legal precisely because the widget does not exist yet
# on this run.
#
# Changing either one triggers a normal rerun, so window_key/unit_key
# and every table below are recomputed from the new value. Nothing
# downstream needs to know there is more than one picker.
_WINDOW_OPTIONS = [
    "Season",
    "Last 75 Games", "Last 50 Games", "Last 25 Games",
    "Last 15 Games", "Last 10 Games", "Last 5 Games",
    "Last 300 PA", "Last 250 PA", "Last 200 PA",
    "Last 60 PA", "Last 25 PA", "Last 15 PA",
    "Last 60 BBE", "Last 25 BBE", "Last 15 BBE", "Last 5 BBE",
]
_WINDOW_STATE = "lineup_window_value"


def _window_control(widget_key, label="Window", label_visibility="visible",
                    help=None):
    """Render a Window picker wired to the single shared setting."""
    current = st.session_state.get(_WINDOW_STATE, "Season")
    if current not in _WINDOW_OPTIONS:
        current = "Season"
    st.session_state[_WINDOW_STATE] = current
    # Seed THIS widget from the shared value before it exists.
    st.session_state[widget_key] = current

    def _sync():
        st.session_state[_WINDOW_STATE] = st.session_state[widget_key]

    return st.selectbox(label, _WINDOW_OPTIONS, key=widget_key,
                        on_change=_sync, label_visibility=label_visibility,
                        help=help)


# ---------------------------------------------------------------------
# Helpers hoisted out of the render block.
#

# ======================================================================
# Render sections, lifted out of the `with content_col:` block.
#
# Each was a top-level statement in that block. What it reads is now a
# parameter and what later code needs is a return, so every dependency
# is visible in the signature instead of being an ambient local.
#
# Streamlit's context is dynamic rather than lexical, so calling these
# from inside `with content_col:` still renders into that column.
# ======================================================================

def _render_game_carousel(_labels, games):
    """The whole slate in ONE swipeable row. No pages.

    WHY THIS REPLACED PAGINATION

    It used to show five games at a time behind a prev/next pager and a
    "Page 1 of 3" caption. On an eleven-game slate that meant three
    clicks to see everything and no way to compare the ends of the
    slate. Paging is a desktop compromise; this app is read on an iPad,
    where a horizontal swipe is the native gesture and a pager is two
    small targets to hit.

    HOW IT WORKS WITHOUT LEAVING STREAMLIT

    Streamlit has no carousel, and buttons cannot live inside raw HTML —
    so the row is still st.columns of real st.buttons, and the SCROLLING
    is pure CSS on the container: flex-wrap:nowrap, overflow-x:auto, and
    scroll-snap so each card settles under the thumb instead of stopping
    half-way. Momentum scrolling comes free on iOS.

    The CSS is scoped to this container's own key (st-key-gc_gamestrip),
    the same mechanism every card on the site already uses, so it cannot
    leak into another horizontal block. Rule 9 still holds: nothing here
    depends on a Streamlit-generated class NAME, only on the key we
    ourselves set and the two stable data-testids this file already
    targets elsewhere.

    Selection state is unchanged — same _pick_game callback, same
    gc_selected_game_idx — so nothing downstream had to know about this.
    """
    import streamlit as st

    if not _labels:
        return

    # min-width is what actually makes it scroll: without it Streamlit
    # divides the row evenly and eleven games become eleven slivers.
    # 116px fits a logo pair and an abbreviated matchup without
    # truncating, and shows about four and a half cards on an iPad —
    # the half card being the point, since a row that ends flush looks
    # like the end of the list.
    st.markdown(
        "<style>"
        'div[class*="st-key-gc_gamestrip"] div[data-testid="stHorizontalBlock"] {'
        "  flex-wrap: nowrap !important;"
        "  overflow-x: auto !important;"
        "  scroll-snap-type: x proximity;"
        "  -webkit-overflow-scrolling: touch;"
        "  gap: var(--lc-space-xs) !important;"
        "  padding-bottom: var(--lc-space-xs);"
        "  scrollbar-width: none;"
        "}"
        'div[class*="st-key-gc_gamestrip"] div[data-testid="stHorizontalBlock"]::-webkit-scrollbar {'
        "  display: none;"
        "}"
        'div[class*="st-key-gc_gamestrip"] div[data-testid="stColumn"] {'
        "  flex: 0 0 auto !important;"
        "  width: 116px !important;"
        "  min-width: 116px !important;"
        "  scroll-snap-align: center;"
        "}"
        'div[class*="st-key-gc_gamestrip"] button {'
        "  padding: var(--lc-space-hair) var(--lc-space-xs) !important;"
        "  min-height: 26px !important;"
        "}"
        'div[class*="st-key-gc_gamestrip"] button p {'
        "  font-size: var(--lc-text-tiny) !important;"
        "}"
        "</style>",
        unsafe_allow_html=True,
    )

    with st.container(key="gc_gamestrip"):
        _cols = st.columns(len(_labels))
        for _gidx, (_lbl, _g) in enumerate(zip(_labels, games)):
            _sel = _gidx == st.session_state["gc_selected_game_idx"]
            _a, _h = logo_for(_g.get("away")), logo_for(_g.get("home"))
            _ai = (f'<img src="{_a}" width="21" height="21" style="vertical-align:middle;">'
                   if _a else f'<b style="font-size:var(--lc-text-caption);">{team_abbr(_g.get("away", "?"))}</b>')
            _hi = (f'<img src="{_h}" width="21" height="21" style="vertical-align:middle;">'
                   if _h else f'<b style="font-size:var(--lc-text-caption);">{team_abbr(_g.get("home", "?"))}</b>')
            # First pitch on the card itself. The picker used to carry
            # only the matchup, so choosing between an early game and a
            # night game meant selecting one, reading the breadcrumb,
            # and going back. The time is the second thing anyone wants
            # here and it costs one line.
            try:
                _t = (datetime.fromisoformat(_g["game_time"].replace("Z", "+00:00"))
                      .astimezone(EASTERN).strftime("%-I:%M %p")
                      if _g.get("game_time") else "")
            except Exception:
                _t = ""
            with _cols[_gidx]:
                st.markdown(
                    f'<div class="lc-gamecard" style="text-align:center; '
                    f'padding:var(--lc-space-xs) var(--lc-space-hair) var(--lc-space-hair); '
                    f'border-radius:var(--lc-radius-lg) var(--lc-radius-lg) 0 0; '
                    f'border:{"1px solid " + COLOR["stat_high"] if _sel else "1px solid " + COLOR["text"] + "1A"}; '
                    f'border-bottom:none; '
                    f'background:{COLOR["stat_high"] + "1F" if _sel else "transparent"}; '
                    # The selected card lifts instead of thickening its
                    # border. A 2px border on select and 1px otherwise
                    # shifted every neighbour by a pixel as you moved
                    # along the strip, which reads as jitter on a swipe.
                    f'box-shadow:{"0 0 0 1px " + COLOR["stat_high"] + ", 0 4px 16px -8px " + COLOR["stat_high"] if _sel else "none"};">'
                    f'<div style="white-space:nowrap;">{_ai}'
                    f'<span style="margin:var(--lc-space-none) var(--lc-space-xs); '
                    f'color:{COLOR["text"]}; opacity:0.5; font-size:var(--lc-text-micro);">@</span>{_hi}</div>'
                    f'<div style="font-size:var(--lc-text-micro); margin-top:2px; '
                    f'color:{COLOR["stat_high"] if _sel else COLOR["text"]}; '
                    f'opacity:{1 if _sel else 0.45};">{_t}</div></div>',
                    unsafe_allow_html=True,
                )
                st.button(
                    _lbl, key=f"gpick_{_gidx}", width="stretch",
                    type="primary" if _sel else "secondary",
                    on_click=_pick_game, args=(_gidx,),
                )


def _render_game_headline(game):
    """Centred headline: teams, then one meta line.

    The venue used to sit on its own gold line under the matchup, which
    made two headlines where there is one piece of information. Venue,
    first pitch and the park's HR factor are all context for the same
    game, so they read as one line separated by rules — the eye takes it
    in as a single band instead of three stacked announcements.
    """
    _bits = [game.get("venue") or ""]
    try:
        _bits.append(datetime.fromisoformat(
            game["game_time"].replace("Z", "+00:00")).astimezone(EASTERN)
            .strftime("%-I:%M %p ET") if game.get("game_time") else "")
    except Exception:
        _bits.append("")
    _meta = "".join(
        (f'<span style="color:{COLOR["text"]}; opacity:0.28; '
         f'margin:var(--lc-space-none) var(--lc-space-md);">|</span>' if i else "")
        + f'<span>{b}</span>'
        for i, b in enumerate([x for x in _bits if x])
    )
    st.markdown(
        f'<div style="text-align:center; margin-bottom:var(--lc-space-xs);">'
        f'<span style="font-size:var(--lc-text-display); font-weight:800; '
        f'color:{COLOR["headline"]};">{game["away"]} @ {game["home"]}</span></div>'
        f'<div style="text-align:center; color:{COLOR["gold"]}; '
        f'font-size:var(--lc-text-body); margin-bottom:var(--lc-space-xl);">{_meta}</div>',
        unsafe_allow_html=True,
    )


def _render_conditions_strip(_cond_display, _wind_display, park_display,
                             temp_display, home_team=None):
    """Weather and park factor as one divided band.

    Was four blocks floating in a card with space-around, so the cells
    drifted apart on a wide screen and collided on a narrow one, and
    nothing said where one metric ended and the next began. Now it is a
    fixed four-column grid with hairline rules between the cells: equal
    widths, aligned baselines, and a visible boundary doing the work
    that whitespace was failing to do.

    Order is deliberate — condition, temp, wind, park. The first three
    change every hour and the last one never changes at all, so the
    thing you re-read sits first and the constant anchors the end.
    """
    _cells = (
        ("Condition", f'<div class="lc-weather-icon" style="height:28px;">'
                      f'{weather_icon(_cond_display)}</div>', _cond_display),
        ("Temp", f'<div style="height:28px;">{temp_icon(temp_display)}</div>',
         f"{temp_display}\u00b0F"),
        # home_team is what lets a compass FORECAST point at the field.
        #
        # MLB does not publish gameData.weather until close to first
        # pitch, so a morning card has only "SW 10 mph*" — a real-world
        # bearing that means nothing without knowing which way the park
        # faces. wind_engine carries the home-plate-to-centre-field
        # bearing for 29 parks, and the Weather Board was already
        # passing it; this call was not, so the same wind resolved on
        # one page and drew a neutral swirl on the other.
        ("Wind", f'<div class="lc-wind-icon" style="height:28px;">'
                 f'{wind_arrow(_wind_display, home_team=home_team)}</div>',
         _wind_display),
        ("Park Factor", f'<div style="height:28px;">{park_icon(park_display)}</div>',
         park_display),
    )
    st.markdown(
        f'<div style="display:grid; grid-template-columns:repeat(4, 1fr); '
        f'border-top:1px solid {COLOR["text"]}14; border-bottom:1px solid {COLOR["text"]}14; '
        f'margin-bottom:var(--lc-space-lg);">'
        + "".join(
            f'<div style="text-align:center; padding:var(--lc-space-md) var(--lc-space-xs); '
            f'{"border-left:1px solid " + COLOR["text"] + "14;" if i else ""}">'
            f'<div style="font-size:var(--lc-text-micro); letter-spacing:0.12em; '
            f'text-transform:uppercase; color:{COLOR["text_muted"]};">{label}</div>'
            f'<div style="margin:var(--lc-space-hair) var(--lc-space-none);">{icon}</div>'
            f'<div style="font-size:var(--lc-text-body); color:{COLOR["text"]}; '
            f'font-weight:700;">{value}</div></div>'
            for i, (label, icon, value) in enumerate(_cells)
        )
        + '</div>',
        unsafe_allow_html=True,
    )


def _pick_starting_pitcher(pitcher_options):
    """Starting-pitcher segmented control."""
    pitcher_choice = st.segmented_control(
        "Select Pitcher", pitcher_options, default=pitcher_options[0],
        # Key includes the option labels. The labels can CHANGE mid-session:
        # hand_tag returns "" until the pitcher's dataframe is cached, then
        # "LHP"/"RHP" on a later rerun. With a fixed key, session state
        # would still hold the old label — a value no longer in the options
        # list — which Streamlit either errors on or silently resets.
        # Folding the labels into the key means a label change starts a
        # fresh widget that simply defaults to the away pitcher, exactly as
        # a first visit does.
        key=f"pitcher_choice_{st.session_state['gc_selected_game_idx']}_"
            f"{abs(hash(tuple(pitcher_options))) % 10**8}",
        label_visibility="collapsed",
    )
    return pitcher_choice

def _render_pitcher_header(pitcher_data, pitcher_id, selected_pitcher_name):
    """Pitcher header card — headshot, name, season pitch mix."""
    with card("pitcher_header"):
        col_head, col_mix = st.columns([1, 3])
        with col_head:
            if pitcher_id:
                st.image(get_headshot_url(pitcher_id), width=80)
            # Throwing hand, shown next to the name. It drives the whole
            # platoon side of the model — which side a switch hitter bats
            # from, the batter-vs-hand splits, the park factor that then
            # applies — and it appeared nowhere on the site.
            _hand = (pitcher_data or {}).get("p_throws")
            _hand_tag = (
                f'<span style="font-family:\'JetBrains Mono\',monospace; '
                f'font-size:var(--lc-text-caption); color:{COLOR["text_muted"]}; margin-left:var(--lc-space-sm);">'
                f'{_hand}HP</span>' if _hand in ("R", "L") else "")
            st.markdown(f'<span style="font-weight:700; color:{COLOR["text"]};">'
                        f'{selected_pitcher_name}</span>{_hand_tag}',
                        unsafe_allow_html=True)
            _baa = pitcher_data.get("BA") if pitcher_data else None
            if _baa is not None and (pitcher_data.get("AB") or 0) > 0:
                st.markdown(
                    f'<div style="font-family:\'JetBrains Mono\',monospace; font-size:var(--lc-text-small); '
                    f'color:{COLOR["text"]}; margin-top:var(--lc-space-hair);">BA allowed '
                    f'<span style="font-weight:700; color:{COLOR["stat_high"]};">{_baa:.3f}</span></div>',
                    unsafe_allow_html=True,
                )

        with col_mix:
            st.markdown(f'<div class="pf-card-title" style="margin-bottom:var(--lc-space-md); color:{COLOR["gold"]};">Pitch Mix (Season)</div>', unsafe_allow_html=True)
            arsenal = pitcher_data.get("Pitch Arsenal", {}) if pitcher_data else {}
            if arsenal:
                bars_html = '<div style="display:flex; gap:18px; flex-wrap:wrap;">'
                for pt, usage in sorted(arsenal.items(), key=lambda x: -x[1])[:6]:
                    c = pitch_color(pt)
                    bars_html += (
                        f'<div style="min-width:100px;">'
                        f'<div style="font-size:var(--lc-text-caption); color:{c}; font-weight:600;">{pitch_name(pt)}</div>'
                        f'<div style="height:5px; width:100%; background:{COLOR["surface_raised"]}; border-radius:var(--lc-radius-sm); margin:var(--lc-space-xs) var(--lc-space-none);">'
                        f'<div style="height:5px; width:{min(usage,100)}%; background:{c}; border-radius:var(--lc-radius-sm);"></div>'
                        f'</div>'
                        f'<div style="font-family:\'JetBrains Mono\',monospace; font-size:var(--lc-text-small); color:{COLOR["text"]};">{usage:.2f}%</div>'
                        f'</div>'
                    )
                bars_html += '</div>'
                st.markdown(bars_html, unsafe_allow_html=True)
            else:
                st.caption("No arsenal data available.")
    return arsenal

def _render_pitcher_detail(pitcher_id):
    """Pitcher detail: weak spots, splits and arsenal tables."""
    if pitcher_id:
        with st.expander("\U0001F3AF Weak spots \u2014 where he gets hurt"):
            _ws = get_weak_spots(pitcher_id)
            if _ws.get("error"):
                st.caption(_ws["error"])
            else:
                _render_weak_spots(_ws)


# ONE VISUAL LANGUAGE FOR THE WHOLE WEAK-SPOTS SECTION.
#
# This section used to render in four different idioms stacked on top of
# each other: a borderless HTML table for pitch types, bordered box
# grids for zone bands / times-through-order / batting-order slots, and
# two st.caption prose blobs for halves and caveats. Nothing shared a
# cell size, an alignment, or a legend, and the one sentence explaining
# what red, blue and the em dash meant sat in a paragraph above all of
# it. The reader had to re-learn how to read every block.
#
# Everything below is now the same unit: a labelled row with a
# left-anchored bar whose LENGTH is the xSLG and whose COLOUR is the
# verdict. Length gives you the comparison at a glance — which is the
# actual question, "where is he worst" — and colour gives you the
# threshold. One legend at the top covers every group because every
# group reads identically.
#
# WHY A BAR AND NOT A HEATMAP GRID. A grid of coloured squares makes you
# compare hues, which is slow and defeats anyone colour-blind. A bar
# encodes the same number as length first; colour is confirmation, not
# the only channel. The em-dash cases keep a visible empty track rather
# than vanishing, so "not measured" reads as a real state instead of a
# gap in the layout.

# The bar scale. xSLG below .250 is essentially unheard of and above
# .800 is a disaster, so anchoring the track there spends the full width
# on the range that actually varies instead of wasting half of it.
_WS_FLOOR, _WS_CEIL = 0.250, 0.800


def _ws_bar(v, sample_note=""):
    """One measurement, as a bar. Returns HTML for a table cell."""
    if v is None:
        return (f'<div style="height:14px; border-radius:7px; '
                f'background:{COLOR["text"]}0F;"></div>'
                f'<div style="font-size:var(--lc-text-micro); color:{COLOR["text"]}; '
                f'opacity:0.45; margin-top:2px;">\u2014 {sample_note}</div>')
    pct = max(4.0, min(100.0, (v - _WS_FLOOR) / (_WS_CEIL - _WS_FLOOR) * 100.0))
    c = (COLOR["error"] if v >= XSLG_HOT
         else COLOR["stat_high"] if v <= XSLG_COLD else COLOR["warn"])
    return (f'<div style="height:14px; border-radius:7px; background:{COLOR["text"]}0F; '
            f'position:relative; overflow:hidden;">'
            f'<div style="position:absolute; left:0; top:0; bottom:0; width:{pct:.1f}%; '
            f'background:{c}; opacity:0.85; border-radius:7px;"></div></div>'
            f'<div style="font-size:var(--lc-text-micro); margin-top:2px;">'
            f'<b style="color:{c};">{v:.3f}</b>'
            f'<span style="color:{COLOR["text"]}; opacity:0.45;"> {sample_note}</span></div>')


def _ws_group(title, rows, note=None):
    """A titled block of identical label/bar rows."""
    import streamlit as st
    if not rows:
        return
    st.markdown(
        f'<div style="font-size:var(--lc-text-small); font-weight:700; '
        f'color:{COLOR["text_muted"]}; margin-top:var(--lc-space-lg); '
        f'margin-bottom:var(--lc-space-xs);">{title}</div>',
        unsafe_allow_html=True)
    _tr = "".join(
        f'<tr>'
        f'<td style="width:34%; padding:var(--lc-space-hair) var(--lc-space-md) '
        f'var(--lc-space-hair) 0; font-size:var(--lc-text-caption); '
        f'color:{COLOR["text"]}; vertical-align:top; white-space:nowrap;">{lbl}'
        + (f'<span style="opacity:0.45; font-size:var(--lc-text-micro);"> {sub}</span>'
           if sub else "")
        + f'</td>'
        f'<td style="padding:var(--lc-space-hair) 0; vertical-align:top;">{bar}</td>'
        f'</tr>'
        for lbl, sub, bar in rows
    )
    st.markdown(f'<table style="width:100%; border-collapse:collapse;">{_tr}</table>',
                unsafe_allow_html=True)
    if note:
        st.caption(note)


def _render_weak_spots(_ws):
    """Every weak-spot group, one visual language, one legend."""
    import streamlit as st

    # THE LEGEND IS SHOWN, NOT DESCRIBED.
    #
    # The old version explained red/blue/em-dash in a sentence and then
    # asked you to hold it in your head through four differently-shaped
    # blocks. Three chips cost less space than the sentence did and
    # cannot be misremembered halfway down.
    st.markdown(
        f'<div style="display:flex; gap:var(--lc-space-md); flex-wrap:wrap; '
        f'align-items:center; margin-bottom:var(--lc-space-xs);">'
        + "".join(
            f'<span style="display:inline-flex; align-items:center; gap:6px; '
            f'font-size:var(--lc-text-micro); color:{COLOR["text"]}; opacity:0.8;">'
            f'<span style="width:18px; height:8px; border-radius:4px; '
            f'background:{c}; opacity:0.85; display:inline-block;"></span>{t}</span>'
            for c, t in (
                (COLOR["error"], f"hitters do real damage (\u2265{XSLG_HOT:.3f})"),
                (COLOR["warn"], "middling"),
                (COLOR["stat_high"], f"he wins here (\u2264{XSLG_COLD:.3f})"),
            ))
        + f'<span style="font-size:var(--lc-text-micro); color:{COLOR["text"]}; '
          f'opacity:0.55;">\u2014 = below its sample floor, not measured</span>'
        + '</div>',
        unsafe_allow_html=True)
    st.markdown(
        f'<div class="pf-card-subtitle" style="margin-bottom:var(--lc-space-none);">'
        f'xSLG allowed on contact \u00b7 longer bar = more damage. A rate off a thin '
        f'bucket is noise, so anything under its floor shows an empty track rather '
        f'than a number. Formula and floors in engines/pitcher_weakspots.py.</div>',
        unsafe_allow_html=True)

    # THREE SPATIAL PANELS INSTEAD OF FIFTEEN BARS.
    #
    # See engines/weakspot_view for why. Briefly: a pitch type carries
    # TWO numbers (usage and damage) and a bar can only draw one, so
    # usage was demoted to a subtitle where it stopped being comparable.
    # Up/middle/down is a strike zone that was being drawn sideways.
    # Times-through-the-order is a trend across three points drawn as
    # three unconnected bars, which hides the only thing it says.
    from engines.weakspot_view import arsenal_svg, zone_svg, tto_svg

    _svg = arsenal_svg(_ws.get("pitches", []))
    if _svg:
        st.markdown(f'<div class="pf-card-subtitle">By pitch type \u2014 '
                    f'further right is thrown more often, higher is more '
                    f'damage. Top right is the attack spot.</div>{_svg}',
                    unsafe_allow_html=True)

    _svg = zone_svg(_ws.get("bands", []))
    if _svg:
        st.markdown(f'<div class="pf-card-subtitle">By zone band</div>{_svg}',
                    unsafe_allow_html=True)

    _tto = _ws.get("tto", [])
    _svg = tto_svg(_tto)
    if _svg:
        st.markdown(
            f'<div class="pf-card-subtitle">Times through the order \u2014 '
            f'most starters decline the third time through; a jump here is a '
            f'real bullpen and late-innings angle.</div>{_svg}',
            unsafe_allow_html=True)

    # Halves stay prose-free but join the same grid, so the one group
    # that used to be a sentence now compares directly against the rest.
    _halves = _ws.get("halves", [])
    if any(h.get("xslg") is not None for h in _halves):
        _ws_group(
            "Top vs bottom of the order",
            [(h["half"], "", _ws_bar(h.get("xslg"), "")) for h in _halves],
            note=("Context only, deliberately not scored: a gap here mostly reflects "
                  "that better hitters bat at the top, not a repeatable weakness."))

    # Per batting-order slot (1-9) — the granular version, each slot
    # flagged only above its sample floor. Aligned to tonight's actual
    # hitters in the "vs this lineup" section below the lineup table.
    # THE FLAT 1-9 SLOT LIST IS GONE FROM HERE.
    #
    # Nine slots in batting order is a roster printout: the reader has to
    # scan all nine and hold them in their head, and the panel's own
    # caveat says a slot line partly reflects WHICH hitters batted there
    # rather than the pitcher. On its own it is close to unactionable.
    #
    # It becomes the best read on the page in the "vs this lineup"
    # section further down, where the same numbers are SORTED BY LEAK and
    # joined to tonight's actual hitters. There the caveat stops
    # mattering: the claim is not "he is bad at slot 4", it is "the soft
    # spots in this order line up with these bats tonight".
    _slots = _ws.get("slots", []) if False else []
    if any(s.get("xslg") is not None for s in _slots):
        _ws_group(
            "By batting-order slot",
            [(f'Slot {s["slot"]}', "", _ws_bar(s.get("xslg"), f'{s["bbe"]} bbe'))
             for s in _slots],
            note=("Per-slot splits carry a real caveat \u2014 a slot's line partly "
                  "reflects which hitters happened to bat there across his starts, "
                  "not only his own skill. Slots below the sample floor show an "
                  "empty track and are never flagged. Read it alongside the lineup "
                  "mapping below."))


def _render_dual_arsenal(_arsenal_bars, game):
    """Both starters side by side for arsenal comparison."""
    with card("dual_arsenal"):
        st.markdown(
            f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Both Starters \u2014 Arsenal Comparison</div>'
            f'<div class="pf-card-subtitle">Real usage from each starter\'s own Statcast pitches</div>',
            unsafe_allow_html=True,
        )
        ac, hc = st.columns(2)
        for colx, sp_name, sp_id, team_label in (
            (ac, game.get("away_pitcher", "TBD"), game.get("away_pitcher_id"), game.get("away")),
            (hc, game.get("home_pitcher", "TBD"), game.get("home_pitcher_id"), game.get("home")),
        ):
            with colx:
                st.markdown(f'<div style="font-weight:700; color:{COLOR["text"]}; font-size:var(--lc-text-body);">{sp_name} <span style="color:{COLOR["text_muted"]}; font-weight:600;">({team_abbr(team_label)})</span></div>', unsafe_allow_html=True)
                if sp_id:
                    _arsenal_bars(get_pitcher_statcast(sp_id))
                else:
                    st.caption("Starter not posted yet.")

def _render_bullpen_browser(_arsenal_bars, game):
    """Bullpen browser — any rostered arm on either staff."""
    with st.expander("\U0001F9E4 Bullpen browser \u2014 any pitcher on either staff"):
        st.caption(
            "Bullpen changes flip matchups. Pick any rostered pitcher to see their real "
            "arsenal on demand \u2014 loaded only when you ask, so the page stays fast."
        )
        bp1, bp2 = st.columns(2)
        for colx, team_name in ((bp1, game.get("away")), (bp2, game.get("home"))):
            with colx:
                st.markdown(f'<div style="font-weight:700; color:{COLOR["text"]}; font-size:var(--lc-text-body);">{team_name}</div>', unsafe_allow_html=True)
                staff = [p for p in (get_live_team_roster(team_name) or []) if p.get("is_pitcher")]
                if not staff:
                    st.caption("Roster unavailable right now.")
                    continue
                pick = st.selectbox(
                    "Pitcher", [p["name"] for p in staff],
                    index=None, placeholder="Choose a pitcher\u2026",
                    key=f'bp_{team_name}_{st.session_state["gc_selected_game_idx"]}',
                    label_visibility="collapsed",
                )
                if pick:
                    sel = next((p for p in staff if p["name"] == pick), None)
                    if sel and sel.get("id"):
                        bp_data = get_pitcher_statcast(sel["id"])
                        _arsenal_bars(bp_data)
                        # Opposing lineup vs this arsenal — same real
                        # engine the starter's pitch-matchup stat uses
                        # (get_batter_vs_pitch_types), pointed at this
                        # reliever's top 3 pitches.
                        bp_arsenal = bp_data.get("Pitch Arsenal", {}) if bp_data else {}
                        bp_top3 = [pt for pt, _u in sorted(bp_arsenal.items(), key=lambda x: -x[1])[:3]]
                        if bp_top3:
                            opp_label = game.get("home") if team_name == game.get("away") else game.get("away")
                            opp_side = "home" if opp_label == game.get("home") else "away"
                            opp_batters, opp_src = _bullpen_opponent_batters(game.get("game_pk"), opp_label, opp_side)
                            if opp_batters:
                                bp_rows = []
                                for ob in opp_batters[:9]:
                                    vs = get_batter_vs_pitch_types(ob.get("id"), tuple(bp_top3), window="season", unit="bbe")
                                    bp_rows.append({
                                        "Player": ob.get("name", "?"),
                                        "BA": vs.get("BA"),
                                        "Brl %": vs.get("Brl %"),
                                        "HH %": vs.get("HH %"),
                                        "Whiff %": vs.get("Whiff %"),
                                        "SwStr %": vs.get("SwStr %"),
                                        "Pitches": vs.get("_pitches_seen", 0),
                                    })
                                bp_names = ", ".join(pitch_name(p) for p in bp_top3)
                                _bp_df = pd.DataFrame(bp_rows)
                                st.markdown(
                                    f'<div style="font-size:var(--lc-text-caption); font-weight:700; color:{COLOR["text_muted"]}; '
                                    f'margin-top:var(--lc-space-md);">{opp_label} vs this arsenal ({bp_names})</div>',
                                    unsafe_allow_html=True,
                                )
                                render_html_table(
                                    style_stat_table(
                                        # NOT set_index("Player").
                                        #
                                        # _base_styler calls .hide(axis="index"),
                                        # so anything left in the index is dropped
                                        # before render_html_table ever sees it —
                                        # its own docstring says the row label must
                                        # be a real COLUMN. Indexing by Player
                                        # deleted the batter names from this table
                                        # and left nine anonymous stat rows, which
                                        # is exactly as useful as no table. Keeping
                                        # Player as a column also gets it the
                                        # identity colouring _player_name_column
                                        # applies for free.
                                        _bp_df,
                                        favor_high=["BA", "Brl %", "HH %"],
                                        favor_low=["Whiff %", "SwStr %"],
                                        gradient=True,
                                    # No format call here meant BA rendered
                                    # at two decimals (.25, not .250) while
                                    # the same stat one card away showed
                                    # three. stat_formats matches "Brl %"
                                    # to "Brl%" — spaces don't count — so
                                    # this table's spellings resolve to the
                                    # same entries as everywhere else.
                                    ).format(stat_formats(_bp_df), na_rep="N/A"),
                                    key="gc_666")
                                st.caption(
                                    f"Season numbers vs those pitch types only \u2014 blue rows are the "
                                    f"batters who punish this stuff, red rows are the ones it beats. "
                                    f"Lineup source: {opp_src}. A small Pitches count means a small "
                                    f"sample \u2014 read those rows gently."
                                )
                    else:
                        st.caption("No ID for that pitcher \u2014 no data to show.")

def _resolve_lineup_batters(confirmed_lineup, lineup_confirmed, opposing_team,
                            vs_hand=None):
    """Tonight’s batters, from the confirmed or projected lineup.

    vs_hand is the opposing STARTER's throwing hand. It is used only on
    the projected path, to read each bat's start rate against that hand
    — which is the half of the lineup that actually moves, and is
    knowable in the morning because probables are announced a day
    ahead."""
    if lineup_confirmed:
        batters = [p for p in confirmed_lineup if not p["is_pitcher"]]
    else:
        # MLB hasn't posted today's real lineup yet (normal 1-3 hours
        # before first pitch). Honest fallback #1: this team's REAL 9
        # starters from their most recently completed game (real posted
        # data, not a guess) — this is what belongs here, not an
        # arbitrary slice of the roster. The old fallback below took the
        # first 9 non-pitchers in whatever order the MLB API happened to
        # return the roster in (not sorted by playing time or batting
        # order at all) — which silently cut regulars like a cleanup
        # hitter or DH from the page any time they didn't happen to land
        # in that arbitrary first 9, while bench/depth players did.
        last_lineup, last_game_date, last_confirmed = get_last_starting_lineup(opposing_team)
        if last_confirmed:
            _raw = [p for p in last_lineup if not p["is_pitcher"]]

            # DROP ANYONE NO LONGER ON THE ACTIVE ROSTER.
            #
            # get_last_starting_lineup searches back FOURTEEN days for the
            # most recent completed game, and this fallback is what you're
            # looking at every morning before lineups post. A player who
            # went on the IL nine days ago is still sitting in that
            # lineup — and he'd be scored like anyone else: HR Score,
            # matchup, park, wind, the whole row. Every number correct
            # except whether he's playing.
            #
            # Active-roster membership is MLB's own state and is already
            # being fetched by get_live_team_roster, so this costs nothing.
            # An EMPTY set means the roster call failed, which is unknown,
            # not "nobody is active" — in that case show the lineup as-is
            # rather than blanking the page over one timed-out request.
            _active = get_active_player_ids(opposing_team)
            _dropped = []
            if _active:
                batters = []
                for _p in _raw:
                    if str(_p.get("id")) in _active:
                        batters.append(_p)
                    else:
                        _dropped.append(_p.get("name"))
            else:
                batters = _raw

            st.info(
                f"MLB hasn't posted {opposing_team}'s confirmed starting lineup yet "
                f"(usually posted 1\u20133 hours before first pitch) \u2014 showing their real "
                f"starting 9 from their last game ({last_game_date}) instead. This will switch "
                f"to today's confirmed batting order automatically once MLB posts it."
            )
            if _dropped:
                st.warning(
                    f"Removed from that lineup: {', '.join(_dropped)} — no longer on "
                    f"{opposing_team}'s active roster (traded, IL, optioned, or "
                    f"restricted). They played on {last_game_date} but aren't "
                    f"available today, so scoring them here would be a real-looking "
                    f"number on someone who isn't in the building."
                )
            # ASK FIRST WHICH POOL WE ARE BUILDING.
            #
            # This control used to sit BELOW the returning-bat block,
            # and the two contradicted each other on screen: the floor
            # would announce "Also available today but held back from
            # the table: Will Banfield" and then Full roster mode would
            # add Banfield to the table anyway, three lines further
            # down. Both statements were individually true and the pair
            # was nonsense.
            #
            # Reading the mode first makes the floor conditional on it,
            # which is what it always should have been: a floor exists
            # to decide who is worth ASSERTING into a projected nine.
            # In Full roster mode nothing is being asserted — every
            # available bat is shown by definition — so there is nothing
            # for it to decide.
            _pool_mode = st.segmented_control(
                "Show", ["Full roster", "Projected 9"],
                default="Full roster", key="lineup_pool_mode",
                help=("Full roster shows every available position player "
                      "(~13) with a Lock / Usual / In question tier on "
                      "each \u2014 nobody can be missing. Projected 9 shows "
                      "only last game's posted lineup, which is right "
                      "about 81.7% of the time.")
            )
            _full_roster = _pool_mode != "Projected 9"

            # ADD BACK ANYONE WHO JUST BECAME AVAILABLE.
            #
            # The filter directly above SUBTRACTS. That is the whole
            # shape of the bug this fixes: the projected pool is last
            # game's nine INTERSECTED with the active roster, and an
            # intersection can only ever remove names. A regular
            # activated off the IL today is in neither set — not in last
            # night's card, and not added by a filter that only takes
            # away — so he appears nowhere. No row, no badge, no warning.
            # O'Neil Cruz, 2026-08-19: available, hitting in the middle
            # of the order, and invisible on this page until Pittsburgh
            # posted the card.
            #
            # THIS CANNOT BE RECOVERED FROM USAGE DATA. A returning bat
            # has zero starts in every recent window, so lineup_lock
            # scores him 0% and every rate-based method leaves him out.
            # Measured: the probe on 2026-08-19 put the whole
            # start-rate approach within half a point of simply copying
            # last night's nine, and neither method can produce a name
            # that is in no boxscore. The signal is the roster MOVE.
            #
            # ADDITIVE ON PURPOSE. Nothing above is removed or reordered,
            # so every row that rendered before still renders identically
            # and a failure here costs a returning bat rather than the
            # lineup. get_recent_activations fails open to {}.
            #
            # Not silently: each addition is named, with MLB's own
            # wording and the date, because a bat with no batting order
            # sitting in a projected nine has to say why he is there.
            # WHAT A RETURNING BAT HAS TO CLEAR TO EARN A ROW.
            #
            # Being available is not enough. Every activation adds a
            # name — a backup catcher, a fifth outfielder, a September
            # call-up with eleven career plate appearances — and a row
            # of dashes next to eight real hitters is worse than an
            # absence, because it reads as a hitter who is terrible
            # rather than one who was never measured. This board's whole
            # rule is that blank means NOT MEASURED; a bat who can only
            # ever be blank should not be given the cells.
            #
            # So the same shape as every other board here: FLOOR, then
            # show. Three floors, and what each one is actually for:
            #
            #   1. AVAILABLE — on the active 26, position player, and
            #      his latest roster move is a return not superseded by
            #      a later IL placement. Handled in
            #      roster.get_recent_activations.
            #
            #   2. HE WAS A STARTER, NOT A BENCH BAT.
            #      PA per game appeared >= _RET_MIN_PA_PER_GAME. This is
            #      the floor that does the real work. A bat who plays
            #      nine innings takes four or more trips; a defensive
            #      replacement or pinch hitter takes one or two. Raw PA
            #      cannot separate them, because raw PA also collapses
            #      for a regular who missed two months — which is
            #      exactly the player this whole feature exists for.
            #      Cruz sits above 4; a bench bat sits near 2.
            #
            #   3. THERE IS SOMETHING TO READ.
            #      >= _RET_MIN_PA plate appearances this season, or the
            #      row is a name with no numbers. This is a floor on the
            #      SAMPLE, not on quality: nothing here asks whether he
            #      is any good, only whether the page can say anything
            #      true about him.
            #
            # BOTH NUMBERS ARE PROVISIONAL AND LABELLED AS SUCH. They
            # are reasoned from how the game is played, not measured off
            # this league's own distribution, which is the standard the
            # rest of this repo holds floors to (see hr_floors_probe.py,
            # and the lineup-lock probe that killed a WINDOW_GAMES of 14
            # on 2026-08-19). The probe that would set them properly is
            # the IL-return one: take every activation over a month,
            # measure what share started that day, and cut where the
            # curve actually separates. Until that runs, these are a
            # starting value and nothing downstream may quote them as
            # settled.
            #
            # HELD-BACK BATS ARE NAMED, NEVER SILENTLY DROPPED — the
            # same rule the HR Edge cap follows with its expander. A bat
            # who is available and did not clear the floor is still
            # information; he just does not get scored cells.
            try:
                _returning = get_recent_activations(opposing_team)
            except Exception:
                _returning = {}
            _added, _held = [], []
            if _returning:
                _have = {str(b.get("id")) for b in batters}
                for _p in get_live_team_roster(opposing_team) or []:
                    _pid = str(_p.get("id"))
                    if (_p.get("is_pitcher") or not _p.get("active")
                            or _pid in _have or _pid not in _returning):
                        continue
                    # Season profile, the same cached call every other
                    # bat on this page already makes — so for the one or
                    # two names this loop ever sees, it is free.
                    try:
                        _prof = get_batter_profile_windowed(
                            _p.get("id"), window="season", unit="bbe")
                    except Exception:
                        _prof = {}
                    _pa = _prof.get("PA") or 0
                    _gp = _prof.get("Games") or 0
                    _papg = (_pa / _gp) if _gp else 0.0
                    # The floor only decides who is worth asserting into
                    # a nine. In Full roster mode nothing is asserted, so
                    # it does not apply — and applying it anyway is what
                    # produced the "held back" caption above a table that
                    # then showed them.
                    if not _full_roster and (
                            _pa < _RET_MIN_PA or _papg < _RET_MIN_PA_PER_GAME):
                        _held.append(
                            f"{_p.get('name')} ({_pa} PA"
                            + (f", {_papg:.1f} per game" if _gp else "")
                            + ")")
                        continue
                    _row = dict(_p)
                    # No batting order exists for him — he is not in any
                    # posted lineup. Left absent rather than invented, so
                    # the Ord column renders blank exactly as it does for
                    # every other projected row.
                    _row["battingOrder"] = None
                    _row["returning_note"] = _returning[_pid]
                    batters.append(_row)
                    _added.append(
                        f"{_p.get('name')} \u2014 {_returning[_pid]} "
                        f"[{_pa} PA, {_papg:.1f} per game]")
            if _added:
                st.success(
                    "Added back \u2014 available today but not in that lineup: "
                    + "; ".join(_added)
                    + ". These bats were activated, reinstated or recalled "
                    "since that game, so they could not appear in it, and "
                    "each clears the returning-bat floor "
                    f"({_RET_MIN_PA}+ PA this season and {_RET_MIN_PA_PER_GAME}+ "
                    "PA per game appeared \u2014 a starter's workload, not a "
                    "bench bat's). They carry no batting order because MLB "
                    "hasn't posted one yet; every stat on their row is their "
                    "own real history. MEASURED: only "
                    f"{_RET_START_RATE * 100:.0f}% of returning bats clearing "
                    "this floor actually started that day (60-day sample, 290 "
                    "returns), so treat these as in question rather than as "
                    "projected starters — O'Neil Cruz came off the 60-day "
                    "IL at 4.4 PA per game and did not start."
                )
            if _held and not _full_roster:
                st.caption(
                    "Also available today but held back from the table: "
                    + "; ".join(_held)
                    + f" \u2014 below the {_RET_MIN_PA} PA / "
                    f"{_RET_MIN_PA_PER_GAME} per game floor, so a row for them "
                    "would be mostly blank cells. Named here rather than "
                    "dropped, because he is on the roster whether or not this "
                    "page can say anything true about him."
                )
            # SHOW THE POOL, NOT A GUESS AT THE NINE.
            #
            # Everything above still tries to reconstruct a starting
            # nine, and a nine is the one thing that genuinely cannot be
            # known before MLB posts it. Measured 2026-08-19: repeating
            # last game's lineup is right about 81.7% of the time, so
            # roughly two of any nine here are wrong, and no method
            # beats that by more than half a point.
            #
            # So stop competing on the nine. An active roster carries
            # about 13 position players, and the useful question before
            # first pitch is not "which nine" but "which of these 13,
            # and how sure are we about each". Showing all 13 cannot
            # omit a starter — the failure mode that hid O'Neil Cruz,
            # and that leaves an acquired bat off this card entirely.
            #
            # ADDITIVE, like the returning-bat block above. The nine
            # from the last posted lineup keep their batting order and
            # their position at the top; the rest arrive under them with
            # a blank Ord, which is exactly what they are — available,
            # unordered. lineup_lock.attach below then tiers every row
            # Lock / Usual / In question / Rare, so the extras are
            # labelled rather than dumped in looking like starters.
            #
            # NO FLOOR HERE, unlike the returning-bat add-back. That
            # floor exists because a returning bat is ASSERTED to be
            # interesting; these are explicitly the bench, they are
            # labelled as such by their tier, and a thin row among them
            # reads correctly as a thin bench bat.
            if _full_roster:
                _have = {str(b.get("id")) for b in batters}
                _extra = 0
                for _p in get_live_team_roster(opposing_team) or []:
                    if _p.get("is_pitcher") or not _p.get("active"):
                        continue
                    if str(_p.get("id")) in _have:
                        continue
                    _row = dict(_p)
                    _row["battingOrder"] = None
                    batters.append(_row)
                    _extra += 1
                if _extra:
                    st.caption(
                        f"Plus {_extra} more available position player(s) with "
                        "no batting order \u2014 they were not in that lineup but "
                        "are on the active roster today. Read their tier, not "
                        "their position in this table: a bat with no Ord is a "
                        "candidate, not a projected starter."
                    )
            # The other half of a trade. A player acquired since that game
            # was never in it, so he cannot appear in the nine above — the
            # nine are real, they are just the nine from BEFORE the deal.
            # Full roster mode does pick him up, which is one more reason
            # it is the default.
            st.caption(
                "The ordered nine are from that date. Anyone acquired since "
                "then appears only in Full roster mode, without an order, "
                "until MLB posts today's confirmed lineup."
            )
        else:
            # Fallback #2: no completed game in the last 14 days to pull a
            # real lineup from (e.g. after a long break) — show the full
            # position-player roster rather than an arbitrary, misleading
            # slice of it, clearly labeled as just the roster.
            roster = get_live_team_roster(opposing_team)
            batters = [p for p in roster if not p["is_pitcher"]]
            st.info(
                f"MLB hasn't posted {opposing_team}'s confirmed starting lineup yet, and there's "
                f"no recent game to pull a real starting 9 from \u2014 showing their full roster "
                f"below instead. This will switch to the real confirmed batting order automatically "
                f"once MLB posts it."
            )

        # WHICH OF THESE NINE IS ACTUALLY GOING TO PLAY.
        #
        # Everything above produces a real, honestly-labelled projected
        # lineup, and every row in it looked equally certain. Measured
        # on the research log, about 80% of a team's bats repeat from
        # one game to the next — so roughly two of these nine are wrong
        # by first pitch, and they are not random: the catcher, the
        # platoon corner, the DH rotation.
        #
        # Read-only (engines/lineup_lock has no build path), so this
        # costs one cached file read. Confirmed lineups skip it
        # entirely: once MLB has posted the order there is nothing left
        # to project.
        if lineup_lock.available():
            lineup_lock.attach(batters, opposing_team, vs_hand)
            _cap = lineup_lock.caption(batters)
            if _cap:
                st.caption(_cap)
    return batters

def _attach_batter_profiles(batter_profiles, batters):
    """Attach the ID-matched batted-ball profile to each batter."""
    for b in batters:
        # Real, ID-matched batted-ball profile — same reliable engine
        # SLAM uses, not the old name-matching one. Eliminates the
        # missing-fields bug AND the accented-name matching failures
        # in one move, since there's no name string involved at all.
        profile = get_batter_profile_windowed(b.get("id"), window="season", unit="bbe")
        # battingOrder carried through so the opportunity factor and the
        # 1-9 display order both have it. Present only on CONFIRMED
        # lineups — the fallback path has no batting order, and the slot
        # adjustment correctly sits out there rather than inventing one.
        batter_profiles.append({"name": b["name"], "bats": b.get("bats") or "?",
                                "id": b.get("id"), "profile": profile,
                                "battingOrder": b.get("battingOrder")})

def _compute_matchup_edges(_p_throws, game, opposing_team, pitcher_data, pitcher_id, ranked):
    """Per-batter matchup grade against this arsenal."""
    if ranked and pitcher_id:
        _pitcher_team = game["away"] if opposing_team == game["home"] else game["home"]
        # Wording no longer promises a ~30s wait. That was true when the
        # first lineup of the day built the slate-wide pen baseline live —
        # one roster call plus a splits derive and a hand lookup per arm,
        # for all 30 teams. precompute.build_bullpen_profiles now ships
        # that nightly and edge._pen_profile_json reads it locally, so the
        # warm path is microseconds. Telling a subscriber to expect half a
        # minute makes the app feel slower than it is.
        with st.spinner("Computing matchup edges\u2026"):
            # Warm-up call only — the RESULT is discarded. Its job is to
            # build the slate-wide pen baseline behind the spinner above,
            # which takes ~30s on the first game of the day. The values
            # that actually reach the board are resolved per batter
            # further down, since the pen adjustment now depends on each
            # hitter's platoon split.
            pen_context(_pitcher_team, pitcher_id)
            # Tonight's park, keyed by Statcast's team code — that's what
            # build_park_hr_factors groups on. game["home"] is the full
            # club name, so it has to be abbreviated here or every lookup
            # would silently miss and return no adjustment.
            _park_abbr = team_abbr(game["home"])
            _temp = game.get("weather_temp")
            # Compass forecasts ("SW 12 mph") are now usable: wind_engine
            # resolves them against this park's real orientation.
            _wind = game.get("weather_wind")
            # Full pitch-type interaction here: a Game Card is ~18
            # hitters, so per-pitch profiles are affordable. Limited to
            # the pitcher's top 3 offerings — beyond that usage is too
            # low to carry signal and the slices stop being free.
            _arsenal = (pitcher_data or {}).get("Pitch Arsenal") or {}
            _top_pitches = tuple(
                p for p, _u in sorted(_arsenal.items(), key=lambda kv: -kv[1])[:3])
            for _r in ranked:
                # EFFECTIVE hand for tonight. Park splits by hand are
                # large, so handing edge_components a raw "S" would apply
                # the wrong split to exactly the hitters it matters most
                # for. A switch hitter bats opposite the pitcher's throwing
                # hand; everyone else bats their own side.
                #
                # Resolved inline rather than via _side_for(), which does
                # the same thing but is defined further down in the lineup
                # table block and is NOT in scope here.
                _b = (_r.get("bats") or "").upper()
                if _b == "S":
                    _eff_bats = "L" if _p_throws == "R" else "R" if _p_throws == "L" else None
                else:
                    _eff_bats = _b
                # Per batter: the pen adjustment now includes how this
                # hitter handles the hand the pen actually throws, so the
                # matchup read doesn't expire when the starter is pulled.
                _pa, _pn = pen_context(_pitcher_team, pitcher_id,
                                       batter_id=_r.get("id"))
                _r.update(edge_components(_r.get("id"), pitcher_id,
                                          _r.get("hr_score"), _pa, _pn,
                                          home_team=_park_abbr,
                                          bats=_eff_bats,
                                          temp=_temp, wind=_wind,
                                          arsenal=_arsenal,
                                          batting_order=_r.get("battingOrder"),
                                          batter_vs_pitch=_batter_pitch_profile(
                                              _r.get("id"), _top_pitches)
                                          if _top_pitches and _r.get("id") else None))
                if _p_throws in ("R", "L") and _r.get("id"):
                    _r["iso_vs_hand"] = get_batter_iso_vs_hand(_r["id"], _p_throws)
                    _r["opp_hand"] = f"{_p_throws}HP"

def _render_top_plays(league_data_available, opposing_team, ranked):
    """Top plays panel: HR, hit and strikeout target tables."""
    if not ranked:
        st.info(f"No lineup data available for {opposing_team} right now.")
    else:
        if not league_data_available:
            st.caption("Scores below will show as N/A \u2014 see warning above.")

        def _targets_table(sort_field, label):
            """Rows for one targets card.

            Keeps None as None rather than passing through _score_num.
            _score_num's own docstring justifies substituting 0 on the
            grounds that it is "always paired with the N/A text elsewhere
            so it's never the only signal" — but in THIS table the number
            is the only signal. When Savant is unreachable every score
            rendered as a hard 0, which reads as "this hitter is the worst
            in the league" rather than "we couldn't measure him". The
            warning banner above even promised N/A while the table said 0.

            None becomes NaN in the frame and the styler renders it as
            N/A, matching both the banner and the Stack Pick card beside
            it — which was already correct.
            """
            rows = []
            for r in sorted(ranked, key=lambda x: _score_sort_key(x, sort_field))[:5]:
                rows.append({"Player": r["name"], "Bats": r["bats"],
                             label: r[sort_field]})
            return pd.DataFrame(rows)

        top_row1, top_row2 = st.columns(2)
        with top_row1:
            with card("hr_targets"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Top HR Targets</div>', unsafe_allow_html=True)
                hr_df = _targets_table("hr_score", "HR Score")
                render_html_table(
                    # Bar, not a flat coloured cell — same treatment as the
                    # lineup and HR Edge boards. favor_high dropped so the
                    # cell gradient does not sit behind the bar and swallow
                    # its track.
                    style_stat_table(hr_df, gradient=True).format(
                        {"HR Score": score_bar("stat_high")}, na_rep="N/A"),
                    key="gc_918")
        with top_row2:
            with card("hit_targets"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Best Hit Targets</div>', unsafe_allow_html=True)
                hit_df = _targets_table("hit_score", "Hit Score")
                render_html_table(
                    # Bar, not a flat coloured cell — same treatment as the
                    # lineup and HR Edge boards. favor_high dropped so the
                    # cell gradient does not sit behind the bar and swallow
                    # its track.
                    style_stat_table(hit_df, gradient=True).format(
                        {"Hit Score": score_bar("warn")}, na_rep="N/A"),
                    key="gc_923")

        bot_row1, bot_row2 = st.columns(2)
        with bot_row1:
            with card("k_targets"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Strikeout Targets</div>', unsafe_allow_html=True)
                k_df = _targets_table("k_score", "K Score")
                render_html_table(
                    # Bar, not a flat coloured cell — same treatment as the
                    # lineup and HR Edge boards. favor_high dropped so the
                    # cell gradient does not sit behind the bar and swallow
                    # its track.
                    style_stat_table(k_df, gradient=True).format(
                        {"K Score": score_bar("gold")}, na_rep="N/A"),
                    key="gc_930")
        with bot_row2:
            hr_vals = [r["hr_score"] for r in ranked if r["hr_score"] is not None]
            hit_vals = [r["hit_score"] for r in ranked if r["hit_score"] is not None]
            avg_hr = round(sum(hr_vals) / len(hr_vals)) if hr_vals else None
            avg_hit = round(sum(hit_vals) / len(hit_vals)) if hit_vals else None
            with card("stack_pick"):
                st.markdown(
                    f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Stack Pick</div>'
                    f'<div style="font-size:var(--lc-text-subhead); font-weight:800; color:{COLOR["text"]}; margin-bottom:var(--lc-space-lg);">{opposing_team}</div>'
                    f'<div style="display:flex; gap:16px;">'
                    f'<div><div style="font-family:\'JetBrains Mono\',monospace; font-size:var(--lc-text-stat); font-weight:700; color:{COLOR["stat_high"]};">{_score_display(avg_hr)}</div>'
                    f'<div style="font-size:var(--lc-text-tiny); color:{COLOR["text_muted"]}; text-transform:uppercase;">Avg HR Score</div></div>'
                    f'<div><div style="font-family:\'JetBrains Mono\',monospace; font-size:var(--lc-text-stat); font-weight:700; color:{COLOR["warn"]};">{_score_display(avg_hit)}</div>'
                    f'<div style="font-size:var(--lc-text-tiny); color:{COLOR["text_muted"]}; text-transform:uppercase;">Avg Hit Score</div></div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

# These were defined INSIDE the 2,000-line `with content_col:` statement,
# so nothing could reach them — not a test, not another view, not even a
# different part of this file. All seven are closure-free: they read only
# their arguments and module-level names, so lifting them here changes no
# behaviour.
#
# Dedenting these is fussier than it looks. A plain textwrap.dedent also
# strips the leading spaces from CONTINUATION LINES OF MULTI-LINE STRINGS,
# where that whitespace is string content rather than indentation — it
# silently rewrote three format strings and test_gamecard_columns.py
# caught it. The lines inside multi-line string tokens are copied verbatim.
#
# The block still needs breaking up properly. This is the part that could
# be proven safe without running the app.
# ---------------------------------------------------------------------

def _pick_game(_gidx):
    st.session_state["gc_selected_game_idx"] = _gidx

def _xslg_chip(v):
    if v is None:
        return f'<span style="color:{COLOR["text"]}; opacity:0.4;">\u2014</span>'
    c = (COLOR["error"] if v >= XSLG_HOT
         else COLOR["stat_high"] if v <= XSLG_COLD else COLOR["warn"])
    return (f'<span style="font-weight:800; color:{c};">{v:.3f}</span>')

def _bullpen_opponent_batters(gpk, team_label, side):
    """Light lineup fetch for the bullpen browser, same honest
        fallback order as the main lineup section but without the
        banners: today's confirmed lineup -> real starting 9 from the
        team's last game -> roster. Returns (batters, source_label)."""
    lineup, ok = get_confirmed_lineup(gpk, side)
    if ok:
        return [p for p in lineup if not p.get("is_pitcher")], "today's confirmed lineup"
    last, last_date, ok2 = get_last_starting_lineup(team_label)
    if ok2:
        return [p for p in last if not p.get("is_pitcher")], f"real starting 9 from their last game ({last_date})"
    roster_p = get_live_team_roster(team_label) or []
    return [p for p in roster_p if not p.get("is_pitcher")][:9], "team roster (no lineup posted yet)"

def _score_sort_key(r, field):
    v = r.get(field)
    return -1 if v is None else -v  # None sorts last regardless of view

def _score_display(v):
    return "N/A" if v is None else str(v)

def _score_num(v):
    """0 for display-only numeric contexts (progress bars) \u2014 always
        paired with the N/A text elsewhere so it's never the only signal."""
    return 0 if v is None else v

def _stat_row(name, bats_label, profile, *, boards="", form_pct=None, form_dir=None,
              hr_count=None, near_hr=None, l5_pa=None,
              avg_dist=None, dist_300=None, dist_350=None,
              matchup=None, slam=None,
              hr_edge=None, hr_score=None, hit_score=None, form_deltas=None,
              edge_cell=None, edge_label="", edge_tier="neutral",
              confidence="", batting_order=None, bvp=""):
    """One table row. Score/matchup fields are optional so a
                    switch hitter's non-matchup side can show stats only (its
                    HR/Hit scores would be for the wrong platoon side, so we
                    blank them rather than print a misleading number).

                    `form_deltas` is in that same optional group and for
                    the same reason, but the reason is the opposite one:
                    they are NOT per-side numbers. engines/form measures a
                    hitter against his own baseline with no `stand` filter,
                    so what comes back belongs to the player, not to the L
                    or R row. Printing it on all three rows of a switch
                    hitter would read as three platoon-split form figures
                    that happen to be identical."""
    return {
        "Player": name,
        "Bats": bats_label,
        # 1-9 as posted, sitting with the other identity
        # columns rather than mid-table between HR/FB and
        # Brl%, where it interrupted the run of rate
        # stats. Blank on the unconfirmed-lineup fallback,
        # which genuinely has no batting order.
        "Ord": (batting_order // 100) if batting_order else None,
        "Matchup": matchup if matchup is not None else "\u2014",
        "SLAM": round(slam, 1) if slam is not None else None,
        # FORM, deliberately BESIDE SLAM.
        #
        # Every other number on this row is league-relative — where this
        # hitter sits among other hitters. Form is the only self-relative
        # signal, and putting it next to the widest column on the table
        # keeps it out of the run of Savant percentiles where a reader
        # would take it for one more of them.
        #
        # It renders as "64% ↑": a league PERCENTILE, not an index. 64
        # means hotter than 64% of qualified hitters right now, measured
        # nightly by ranking every hitter's combined L15-vs-season move.
        # The arrow carries direction, which a percentile cannot — 50 is
        # the middle of the league whether the league is hot or cold.
        # WHERE HE SITS ON THE OTHER BOARDS, without opening them.
        #
        # "HR13 \u00b7 H4" means 13th on HR Edge and 4th on Daily 13.
        # Mostly blank by design — only a handful of bats on a slate are
        # on any board — and blank rather than a dash, because a column
        # of dashes reads as missing data instead of as a clean no.
        #
        # Sits with the verdicts: it IS a verdict, just one made on
        # another page.
        "Boards": boards,
        "Form": form_engine.form_cell(form_pct, form_dir),
        # CAREER vs TONIGHT'S STARTER — "0-6, 3K".
        #
        # Moved out of the per-batter expander, where the one column
        # about THIS matchup specifically was the hardest thing on the
        # page to reach. Blank rather than a dash when there is no
        # history: most bats have never faced tonight's starter, and a
        # column of dashes reads as missing data instead of a clean no
        # (same rule as Boards). Raw counts, no average — 0-for-6 is a
        # fact about six at-bats and ".000" would invite confidence it
        # has not earned; the edge.py tiers that let this move SLAM
        # require 8-12 PA before they do anything.
        #
        # DECLARED HERE, DISPLAYED WITH THE VERDICTS. Position on the
        # table comes from _COL_ORDER, not from where a key sits in this
        # dict, so this lives below Form to keep Form adjacent to SLAM
        # (tests/test_form_percentile) while rendering beside Boards.
        "BvP": bvp,
        # HR and NEAR HR side by side, deliberately.
        #
        # NEAR HR counts balls hit hard enough AND at an angle to leave a
        # park, that did not — the same launch window the LAUNCH axis
        # uses, so a near miss and a home-run trajectory are the same
        # shape by construction rather than by coincidence. Read as a
        # pair: 2 HR against 9 near misses is a hitter the ball is not
        # falling for; 7 against 2 is one who has cashed everything.
        "HR": hr_count,
        "NearHR": near_hr,
        # PA per game over his last five GAMES PLAYED. Every other column
        # here is a RATE; this is the volume those rates get applied to,
        # and a bat batting ninth simply gets fewer swings.
        "L5 PA/G": l5_pa,
        # How FAR his contact travels — a different question from how
        # hard he hits it. Two bats can share an exit velocity and
        # separate by fifty feet on launch angle alone.
        "AvgDist": avg_dist,
        "300+": dist_300,
        "350+": dist_350,
        # THE THREE DENOMINATORS, TOGETHER.
        #
        # Every rate on this row is one of these three counts divided by
        # something, and none of them was on the table. _COL_ORDER below
        # has reserved a slot for PA since the column reorder — and
        # READING_THE_BOARDS documents it twice ("65 PA and 543 PA sit
        # in the same column"; "PA last - equal bats, take the one with
        # 500 behind him") — but _stat_row never emitted the key, so
        # _ordered's `if c in cols` filter dropped it silently and the
        # documented column has never once rendered.
        #
        # They widen left to right, and each one is the denominator of a
        # different family of columns:
        #
        #   Pitches  every pitch seen in the window. Denominator of
        #            SwStr%, and the honest sample behind Whiff% and
        #            anything read off swing decisions.
        #   PA       plate appearances. Denominator of Brl/PA, and the
        #            sample behind BA/ISO/SLG.
        #   BIP      balls in play (Statcast's BBE — type == "X").
        #            Denominator of Brl%, HH%, FB%, GB%, LD%,
        #            SweetSpot%, HRWindow%, PullAir%, FB95% and
        #            Clears% — over half this table.
        #
        # These are COUNTS, so 0 is a real measured value and stays 0.
        # That is the opposite of the rule three lines down for the
        # rates, and deliberately so: a 0.0 HH% is a fabricated
        # measurement, while 0 balls in play is the true and useful
        # reason every rate on that row is blank.
        "Pitches": profile.get("Pitches"),
        "PA": profile.get("PA"),
        "BIP": profile.get("BBE"),
        # NO ", 0" DEFAULTS ON ANY RATE IN THIS ROW.
        #
        # A missing BA is not a .000 BA, a missing HH% is
        # not a 0.0 HH%. The engine returns None for
        # anything it couldn't measure (see
        # _compute_batted_ball_metrics), and na_rep="N/A"
        # on the formatter below renders that honestly.
        # A zero-default here would have quietly undone
        # that at the last step.
        #
        # This used to read "this table has no PA column,
        # so a fabricated 0.0 is indistinguishable from a
        # measured one." It now HAS one, three lines up,
        # which makes the two cases distinguishable for the
        # first time — a rate blank beside BIP 0 is missing
        # data, and a rate blank beside BIP 40 is a real
        # gap in what Statcast tracked. That is a reason to
        # keep the rule, not to relax it: the counts explain
        # the blanks, they do not license filling them in.
        "BA": profile.get("BA"),
        "xwOBA": profile.get("xwOBA"),
        "xSLG": profile.get("xSLG"),
        "ISO": profile.get("ISO"),
        "HR/FB": profile.get("HR/FB"),
        "Brl%": profile.get("Brl %"),
        # Barrels per PLATE APPEARANCE, next to the
        # per-batted-ball rate. The gap between the two
        # IS the read: a bat with a high Brl% and a low
        # Brl/PA barrels well but doesn't put enough
        # balls in play to cash it in.
        "Brl/PA": profile.get("Brl/PA"),
        "HH%": profile.get("HH %"),
        # THE THREE EXIT VELOCITIES, IN THAT ORDER:
        # typical, ceiling, single best.
        #
        # AvgEV was the missing one, and it was already on
        # the HR Edge board — the same measurement, off the
        # same profile bundle. A table showing EV90 and
        # MaxEV without it answers "how hard is his BEST
        # contact" twice and "how hard is his contact"
        # never. It reads from `profile`, so like every
        # other stat column here it follows the Window
        # control.
        "AvgEV": profile.get("AvgEV"),
        # 90th-percentile exit velocity — the scored
        # power ceiling. Max EV sits beside it for
        # interest only; it's a sample of one.
        "EV90": profile.get("EV90"),
        "MaxEV": profile.get("MaxEV"),
        "LD%": profile.get("LD %"),
        "FB%": profile.get("FB %"),
        "GB%": profile.get("GB %"),
        "SweetSpot%": profile.get("SweetSpot %"),
        # Launch angle 20-40 — the HOME RUN band, which
        # is NOT SweetSpot% (8-32, built for overall
        # production and starting at a line drive). Both
        # are shown because they answer different
        # questions and the difference is informative.
        "HRWindow%": profile.get("HRWindow %"),
        "PullAir%": profile.get("PullAir %"),
        "PullBrl%": profile.get("PullBrl %"),
        "Blast%": profile.get("Blast %"),
        # Process, not outcome: bat speed + swing plane +
        # pull tendency. Every other column here is
        # downstream of results, so they all sag together
        # when a power bat goes cold. This one doesn't.
        "HRIntent": profile.get("HRIntent"),
        # Hard-hit FLY BALLS. HH% and FB% are both already
        # above, on their own; this is the intersection,
        # and it's the one that predicts home runs. A 95
        # mph ground ball is a single and a 78 mph fly
        # ball is an out — each inflates one of those two
        # parent columns without being a HR trajectory.
        "FB95%": profile.get("FB95 %"),
        # The launch floor that gets out of ANY park,
        # measured off the league's own outcomes rather
        # than a fence diagram. There is no single angle
        # that does it — the angle needed falls as exit
        # velocity rises — so this is a curve, and these
        # are the balls that sit above it. Rare on
        # purpose: league average is a fraction of a
        # percent, so a bat showing anything here is
        # producing genuine no-doubt contact.
        "Clears%": profile.get("ClearsAnywhere %"),
        # 60% outcome, 40% process. HRIntent above stays
        # visible beside it deliberately — when the two
        # disagree, that gap is the read: high intent with
        # low threat is a home-run swing that isn't
        # landing yet.
        "HRThreat": profile.get("HRThreat"),
        # No ", 0" default: a missing SwStr% is not a
        # 0.00 SwStr%, and 0.00 in this column reads as
        # the best possible value. na_rep on the
        # formatter below renders None as N/A.
        "SwStr%": profile.get("SwStr %"),
        # FORM, AS THE MEASUREMENTS THEMSELVES.
        #
        # This was one column holding a 0-100 index with 50 at the
        # hitter's own baseline. Every input to it was real and the
        # output was not — nobody ever recorded a 63.4 — and it sat in a
        # row of LEAGUE percentiles (HR Score, HRThreat, Savant) looking
        # exactly like one, which is the opposite of what it measured.
        #
        # What ships instead is the subtraction: his recent AvgEV minus
        # his season AvgEV in mph, his recent HH% minus his season HH% in
        # points. Real stats, checkable against Savant, and self-relative
        # in a way the reader can see rather than be told.
        #
        # Spread from the dict rather than named here so the columns are
        # whatever engines/form measures. A third input added there
        # appears on this table with no edit to this file — and, more to
        # the point, cannot be added there and silently missed here.
        **(form_deltas or {}),
        "HR Edge": hr_edge,
        "HR Score": hr_score,
        "Hit Score": hit_score,
        "Edge": edge_cell if edge_cell is not None else edge_tag("\u2014", "neutral"),
        "EdgeLabel": edge_label,
        "EdgeTier": edge_tier,
        "Confidence": confidence,
    }

# Plain container instead of st.columns — keeps the `with content_col:`
# indentation below untouched while letting the page use the full width
# app.py's main column gives it.
sync_latest_button(key="sync_gamecard")

content_col = st.container()

with content_col:
    # -----------------------------------------------------
    # GAME PICKER — one swipeable row, the whole slate, no pages.
    # -----------------------------------------------------
    st.session_state.setdefault("gc_selected_game_idx", 0)
    # Clamp the SELECTED GAME.
    #
    # This index survives reruns, but `games` does not stay the same
    # length: the slate shrinks as games go final and rebuilds shorter on
    # the next data refresh. Someone sitting on game 8 of a 9-game slate
    # would come back to a 6-game slate and hit an IndexError on the
    # lookups below — a hard crash on page load, and an intermittent one,
    # since it depends entirely on which game you last looked at.
    st.session_state["gc_selected_game_idx"] = min(
        st.session_state["gc_selected_game_idx"], len(games) - 1)

    # Doubleheader-safe labels: two games with the same teams used to
    # produce IDENTICAL pills, so selecting by label could only ever
    # reach game 1 of a doubleheader. Append G1/G2 (schedule order)
    # whenever a matchup appears more than once on the slate, keeping
    # single games clean.
    _base_labels = [f"{team_abbr(x['away'])} @ {team_abbr(x['home'])}" for x in games]
    _dh_counter = {}
    _labels = []
    for _lbl in _base_labels:
        if _base_labels.count(_lbl) > 1:
            _dh_counter[_lbl] = _dh_counter.get(_lbl, 0) + 1
            _labels.append(f"{_lbl} \u00b7 G{_dh_counter[_lbl]}")
        else:
            _labels.append(_lbl)

    _render_game_carousel(_labels, games)

    # No "Page 1 of 3" any more — there are no pages. The count still
    # earns its place: it tells you how far the strip scrolls, which a
    # row with a half-visible card at the edge only hints at.
    st.markdown(
        f'<div style="color:{COLOR["text"]}; font-size:var(--lc-text-body); font-weight:600; '
        f'margin:var(--lc-space-xs) var(--lc-space-none) var(--lc-space-lg) var(--lc-space-none);">'
        f'{len(games)} game{"s" if len(games) != 1 else ""} today '
        f'<span style="opacity:0.5; font-weight:400; font-size:var(--lc-text-small);">'
        f'\u2014 swipe to see them all</span></div>',
        unsafe_allow_html=True,
    )
    game = games[st.session_state["gc_selected_game_idx"]]

    # WARM THIS GAME'S REQUESTS IN PARALLEL, ONCE, BEFORE ANYTHING READS.
    #
    # prefetch_slate already existed and hr_edge_board and daily_13
    # already call it. This card never did — so the page a reader spends
    # the most time in was the one place still making its MLB calls one
    # at a time, each waiting on the last: both rosters, the boxscore,
    # and (since the returning-bat work) each club's transactions.
    #
    # Warming them together turns that chain into one concurrent batch.
    # PURELY AN OPTIMISATION — every function below still works if this
    # never runs or fails; they just go back to fetching serially. Hence
    # the bare except: a prefetch that raises must never take down a card
    # that would otherwise render fine.
    try:
        prefetch_slate(
            team_names=[t for t in (game.get("away"), game.get("home")) if t],
            game_sides=[(game.get("game_pk"), s)
                        for s in ("away", "home") if game.get("game_pk")],
        )
    except Exception:
        pass

    # -----------------------------------------------------
    # BREADCRUMB
    # -----------------------------------------------------
    try:
        game_time_str = datetime.fromisoformat(game["game_time"].replace("Z", "+00:00")).astimezone(EASTERN).strftime("%-I:%M %p ET") if game.get("game_time") else "TBD"
    except Exception:
        game_time_str = "TBD"
    st.markdown(
        f'<div style="font-size:var(--lc-text-small); color:{COLOR["text_muted"]}; margin-bottom:var(--lc-space-lg);">'
        f'MLB &nbsp;\u203a&nbsp; {game["away"]} @ {game["home"]} &nbsp;\u203a&nbsp; Today, {game_time_str}</div>',
        unsafe_allow_html=True,
    )

    if view not in LIVE_VIEWS:
        with card("coming_soon"):
            st.markdown(f'<div class="pf-card-title">{view}</div><div class="pf-card-subtitle">Coming soon \u2014 not wired up yet</div>', unsafe_allow_html=True)
            st.info(f"The {view} view isn't built yet. Matchup and Top Plays are live; the rest are next.")
        footer()
        st.stop()

    # -----------------------------------------------------
    # MATCHUP HEADER
    # -----------------------------------------------------
    _render_game_headline(game)

    # -----------------------------------------------------
    # WEATHER + PARK FACTOR \u2014 one compact row, not 4 separate cards
    # -----------------------------------------------------
    park = get_park_factor(game["home"])

    # In-house weather desk: MLB's posted park weather is the source of
    # truth the moment it exists (it carries field-relative wind like
    # "Out To CF"). Until then — most of the day — fill the card with
    # the REAL game-time forecast from the National Weather Service
    # (public-domain US government data), marked with * as a forecast.
    _fc = None
    if not game.get("weather_temp") or not game.get("weather_wind"):
        _fc = get_park_forecast(game.get("venue"), game.get("game_time"))
    _cond_display = game["weather_condition"] or (_fc and _fc.get("short")) or "Not posted yet"
    if game["weather_temp"]:
        temp_display = game["weather_temp"]
    elif _fc and _fc.get("temp") is not None:
        temp_display = f'{_fc["temp"]}*'
    else:
        temp_display = "\u2014"
    _wind_display = game["weather_wind"] or (
        f'{_fc["wind"]}*' if _fc and _fc.get("wind") else "Not posted yet")
    park_display = f'{park["park_factor"]}' if park["verified"] else "Not verified"





    _render_conditions_strip(_cond_display, _wind_display, park_display,
                             temp_display,
                             home_team=team_abbr(game.get("home") or ""))

    if _fc:
        st.caption(
            f"* Game-time forecast for {game.get('venue', 'this park')} "
            f"(around {_fc.get('hour_local', '?')} local) \u00b7 precip chance {_fc.get('precip', 0)}% \u00b7 "
            f"Source: National Weather Service \u2014 public-domain US government data, this app's own "
            f"weather desk. Switches to MLB's official park weather (with field-relative wind) "
            f"automatically once posted."
        )

    # -----------------------------------------------------
    # PITCHER SELECTOR
    # -----------------------------------------------------
    # Handedness in the SELECTOR, not just after you've picked. Which way
    # a starter throws is often the reason you'd pick one side of the
    # matchup to look at, so having to select him first to find out had it
    # backwards. Both ids are resolved here anyway and get_pitcher_hand is
    # cached, so labelling both costs nothing.
    #
    # The name stays FIRST in each label: the startswith() checks below
    # match on game['away_pitcher'] / game['home_pitcher'], so anything
    # appended is safe but a prefix would break the selection.
    _away_ht = hand_tag(game.get("away_pitcher_id"))
    _home_ht = hand_tag(game.get("home_pitcher_id"))
    pitcher_options = [
        f"{game['away_pitcher']} ({game['away']}{', ' + _away_ht if _away_ht else ''})",
        f"{game['home_pitcher']} ({game['home']}{', ' + _home_ht if _home_ht else ''})",
    ]
    st.markdown(f'<div style="font-size:var(--lc-text-body-lg); font-weight:600; color:{COLOR["text"]}; margin-bottom:var(--lc-space-xs);">Select Pitcher</div>', unsafe_allow_html=True)
    pitcher_choice = _pick_starting_pitcher(pitcher_options)

    if not pitcher_choice:
        pitcher_choice = pitcher_options[0]
    selected_pitcher_name = game["away_pitcher"] if pitcher_choice.startswith(game["away_pitcher"]) else game["home_pitcher"]
    opposing_team = game["home"] if pitcher_choice.startswith(game["away_pitcher"]) else game["away"]

    # The pitcher's real MLBAM id comes from MLB's schedule feed. If MLB
    # hasn't posted a probable pitcher yet, we show the honest warning
    # below instead of falling back to a name lookup (which downloaded
    # pybaseball's entire player register into memory).
    real_pitcher_id = game["away_pitcher_id"] if pitcher_choice.startswith(game["away_pitcher"]) else game["home_pitcher_id"]
    pitcher_id = real_pitcher_id
    pitcher_data = get_pitcher_statcast(pitcher_id) if pitcher_id else {}

    if pitcher_id is None:
        st.warning(f"Couldn't resolve a player ID for {selected_pitcher_name} \u2014 stats below will be empty.")

    # The season-only splits_vs_r / splits_vs_l fetches that used to sit
    # here are GONE. They were the Matchup table's only consumers, and
    # that table now fetches per selected window instead — so leaving
    # them would have been two cached calls whose results nothing read,
    # which is rule 20 in its plainest form. The Matchup branch does its
    # own fetch; get_pitcher_advanced_splits is cached on (id, side,
    # window), so the Season selection costs exactly what this did.

    # -----------------------------------------------------
    # PITCHER HEADER + PITCH MIX (colored bars, real usage%)
    # -----------------------------------------------------
    arsenal = _render_pitcher_header(pitcher_data, pitcher_id, selected_pitcher_name)

    # -----------------------------------------------------
    # WEAK SPOTS — where this starter actually gets hurt
    # -----------------------------------------------------
    _render_pitcher_detail(pitcher_id)

    # -----------------------------------------------------
    # MATCHUP GRADES — transparent signal checklists, both starters
    # -----------------------------------------------------
    # Grade window — Season is the exact formula that's been hitting;
    # L25/L15/L10/L5 re-run the SAME checklist on both starters' last
    # N games only. Widget return value is read directly, so it takes
    # effect on the first click.
    _gw_opts = {"Season": "season", "L25": "l25", "L15": "l15", "L10": "l10", "L5": "l5"}
    _gw_choice = st.segmented_control(
        "Grade window", list(_gw_opts.keys()), default="Season",
        key="gc_grade_window", label_visibility="collapsed",
    )
    _gw_label = _gw_choice or "Season"
    _grade_window = _gw_opts.get(_gw_label, "season")
    grades = grade_matchup(
        game.get("away_pitcher_id"), game.get("home_pitcher_id"),
        game.get("away_pitcher", "Away"), game.get("home_pitcher", "Home"),
        park_factor=park.get("park_factor"), park_verified=park.get("verified", False),
        temp=game.get("weather_temp"), window=_grade_window,
    )
    # ONE RENDERER FOR EVERY SPORT.
    #
    # This block used to be a hand-rolled copy of the same card the
    # KBO/NPB/WNBA pages render through
    # engines/matchup_grades_intl.render_matchup_grades_card. Two copies
    # meant the improvements — the grade as a coloured badge, the
    # dropped "Lean:" prefix that only restated its own heading, the
    # retired checkmarks — landed on the international pages and never
    # reached the MLB Game Card, which is the page most people actually
    # open.
    #
    # The renderer lives in the _intl module for historical reasons
    # only; nothing in it is sport-specific. MLB passes no accent, so it
    # keeps the house gold exactly as before.
    render_matchup_grades_card(
        grades,
        subtitle=("This app's own signal checklists from real Statcast splits, "
                  "park factor, and posted weather \u2014 formula documented in "
                  "engines/matchup_grades.py. Not calibrated probabilities."),
        source_line=None,
        key="mlb",
        title=f"Matchup Grades \u00b7 {_gw_label}",
    )

    # -----------------------------------------------------
    # THE GAME MODEL — projected score, win %, fair line.
    # Fitted nightly (mlb_model_precompute.py) and walk-forward tested;
    # this only reads data/mlb/model.json and does arithmetic, no
    # network. Sits under the grades on purpose: the grades are a
    # checklist and say so; this is the calibrated number.
    # -----------------------------------------------------
    _mlb_model = _mlb_game_model.load_model()
    if _mlb_model:
        with card("gc_game_model"):
            st.markdown(
                f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Game Model</div>'
                f'<div class="pf-card-subtitle">Projected runs, win probability and the fair '
                f'line \u2014 fitted on this season\'s finals, tested on games it had not seen.</div>',
                unsafe_allow_html=True)
            _gm_proj = _mlb_game_model.project_game(
                game["home"], game["away"], game.get("home_pitcher_id"),
                game.get("away_pitcher_id"), model=_mlb_model)
            _gm_note = None
            if _gm_proj and _mlb_model.get("use_starters") and not _gm_proj.get("starters_used"):
                _gm_note = "Starters not both on record \u2014 team rates only for this game."
            _model_view.render_game_projection(
                _gm_proj, team_abbr(game["away"]), team_abbr(game["home"]),
                key="gc_model", note=_gm_note)
            _model_view.render_validation(_mlb_model.get("validation"), key="gc_model",
                                          total_unit="runs")

    # -----------------------------------------------------
    # BOTH STARTERS + BULLPEN — full-staff arsenal browser
    # -----------------------------------------------------
    def _arsenal_bars(p_data):
        arsenal_d = p_data.get("Pitch Arsenal", {}) if p_data else {}
        if not arsenal_d:
            st.caption("No arsenal data available.")
            return
        html = ""
        for pt, usage in sorted(arsenal_d.items(), key=lambda x: -x[1])[:6]:
            c = pitch_color(pt)
            html += (
                f'<div style="margin-bottom:var(--lc-space-sm);">'
                f'<div style="display:flex; justify-content:space-between;">'
                f'<span style="font-size:var(--lc-text-caption); color:{c}; font-weight:600;">{pitch_name(pt)}</span>'
                f'<span style="font-family:\'JetBrains Mono\',monospace; font-size:var(--lc-text-caption); color:{COLOR["text"]};">{usage:.1f}%</span>'
                f'</div>'
                f'<div style="height:5px; width:100%; background:{COLOR["surface_raised"]}; border-radius:var(--lc-radius-sm);">'
                f'<div style="height:5px; width:{min(usage,100)}%; background:{c}; border-radius:var(--lc-radius-sm);"></div>'
                f'</div></div>'
            )
        st.markdown(html, unsafe_allow_html=True)

    _render_dual_arsenal(_arsenal_bars, game)

    _render_bullpen_browser(_arsenal_bars, game)

    # -----------------------------------------------------
    # LOAD LINEUP + SCORES (shared across everything below)
    # -----------------------------------------------------
    opposing_side = "home" if opposing_team == game["home"] else "away"
    confirmed_lineup, lineup_confirmed = get_confirmed_lineup(game.get("game_pk"), opposing_side)

    batters = _resolve_lineup_batters(confirmed_lineup, lineup_confirmed, opposing_team,
                                     vs_hand=get_pitcher_hand(pitcher_id) if pitcher_id else None)

    # PLAYER PROPS from the same model family — this lineup against the
    # starter selected above. Collapsed by default: the lineup table below
    # is the page's main event, and this reads the same cached parquet
    # frames the profiles load anyway.
    with st.expander(f"Prop model \u2014 {team_abbr(opposing_team)} lineup vs {selected_pitcher_name}",
                     expanded=False):
        _p_rows, _p_verdicts, _p_note = _model_view.mlb_lineup_props(batters, pitcher_id)
        _model_view.render_prop_table(_p_rows, _model_view.MLB_PROP_COLUMNS, _p_verdicts,
                                      key="gc_props", favor_note=_p_note)
        st.caption(_model_view.MLB_PROP_FOOTNOTE)

    # HR Score / Hit Score / K Score come from a SEPARATE, real, live
    # source: MLB's own Statcast percentile rankings, matched by player
    # ID. This doesn't depend on FanGraphs at all, so it doesn't have
    # the "blocked from cloud hosts" problem the old version did.
    savant_df, savant_error = load_percentile_ranks()
    league_data_available = savant_df is not None and not savant_df.empty
    if not league_data_available:
        st.warning(
            f"Baseball Savant's live percentile rankings aren't reachable right now "
            f"({savant_error}). HR Score / Hit Score / K Score below will show as N/A "
            f"until that's back \u2014 raw stats (Brl%, HH%, LD%) are unaffected."
        )

    batter_profiles = []
    _attach_batter_profiles(batter_profiles, batters)

    ranked = rank_batters(batter_profiles, savant_df) if batter_profiles else []

    # ---- Matchup Edge layer (Phase 2): HR Edge = HR Score + BvP(±15)
    # + Zone Fit(±15) + Bullpen(±10). Every component sample-floored
    # and shown in the Edge breakdown below the table. engines/edge.py
    # documents the exact tiers and math.
    # Defined unconditionally: the lineup table reads this for switch
    # hitters even when no probable is posted, and a NameError there
    # would take down the whole page.
    _p_throws = (pitcher_data or {}).get("p_throws") or (pitcher_data or {}).get("Throws")

    _compute_matchup_edges(_p_throws, game, opposing_team, pitcher_data, pitcher_id, ranked)

    # -----------------------------------------------------
    # TODAY'S TOP PLAYS \u2014 plain section label, not its own card,
    # since each item below is now its own standalone card \u2014 a card
    # wrapping four more cards would just nest borders inside borders.
    # -----------------------------------------------------
    st.markdown(
        f'<div class="pf-card-title" style="margin-top:var(--lc-space-sm); color:{COLOR["gold"]};">Today\'s Top Plays</div>'
        f'<div class="pf-card-subtitle">This app\'s own composite scores \u2014 see engines/top_plays.py</div>',
        unsafe_allow_html=True,
    )
    _render_top_plays(league_data_available, opposing_team, ranked)

    # =======================================================
    # VIEW: MATCHUP
    # =======================================================
    if view == "\U0001F3E0 Matchup":
        # SPLITS WINDOW — the missing piece on this table.
        #
        # These three rows were season-only, on a page whose whole job is
        # tonight's matchup. A starter's season line can be four months
        # old and still be the only thing shown; "what has he looked like
        # lately" had no answer here even though every other window
        # control in the app (grade window, lineup, Bullpen Board, Player
        # of the Day) already offered one.
        #
        # Nothing is estimated. get_pitcher_advanced_splits slices the
        # pitcher's raw Statcast rows through recency_windows BEFORE any
        # metric is computed, so IP, the games count and every rate are
        # honest for the window rather than a season figure with a label
        # on it.
        #
        # WHY L3 AND LAST GAME EXIST AT ALL, given the sample problem
        # below: for a starter, L5 can span five weeks. The question a
        # bettor actually has the night of a start is "is he right, right
        # now" — coming off the IL, after a mechanical change, on short
        # rest. That question needs a window shorter than a month, and
        # the data supports it. What it does not support is reading a
        # rate off it without seeing the denominator.
        # L25 / L20 / L15 ADDED 2026-08-17. For a starter these are
        # roughly 140 / 110 / 85 IP.
        #
        # WHAT THEY ARE FOR, AND WHAT THEY ARE NOT. Everything on the
        # pitcher side that stabilises does so at about 70 balls in play
        # — five or six starts — so L15, L20 and L25 are all well past
        # it and the longer two buy no extra stability, only more April.
        # Use them for the batted-ball profile: fly-ball rate, hard
        # contact allowed, what the arsenal actually does.
        #
        # DO NOT read HR-allowed off them. A pitcher's home-run rate
        # needs ~1,320 batters faced and HR/FB ~400 fly balls — north of
        # 200 innings, more than a full season. No window offered here,
        # or offerable in-season, makes that number reliable, and a
        # longer window looks like it should without delivering it.
        _sw_opts = {"Season": "season", "L25": "l25", "L20": "l20",
                    "L15": "l15", "L10": "l10", "L5": "l5",
                    "L3": "l3", "Last game": "l1"}
        _sw_choice = st.segmented_control(
            "Splits window", list(_sw_opts.keys()), default="Season",
            key="gc_splits_window", label_visibility="collapsed",
        )
        _sw_label = _sw_choice or "Season"
        _splits_window = _sw_opts.get(_sw_label, "season")

        st.markdown(
            f'<div class="pf-card-title" style="margin-top:var(--lc-space-sm); color:{COLOR["gold"]};">Splits</div>'
            f'<div class="pf-card-subtitle" style="color:{COLOR["text_muted"]};">Blue = favorable for batter, red = favorable for pitcher \u00b7 IP estimated from Statcast out events (no official box-score feed)</div>',
            unsafe_allow_html=True,
        )
        # Re-fetched per window, per side. All three arguments are
        # hashable and the function is cached, so switching back to a
        # window you already viewed costs nothing.
        splits_overall = (get_pitcher_advanced_splits(pitcher_id, window=_splits_window)
                          if pitcher_id else None)
        _sv_r = (get_pitcher_advanced_splits(pitcher_id, side="R", window=_splits_window)
                 if pitcher_id else None)
        _sv_l = (get_pitcher_advanced_splits(pitcher_id, side="L", window=_splits_window)
                 if pitcher_id else None)
        rows = {"Overall": splits_overall, "vs RHB": _sv_r, "vs LHB": _sv_l}
        rows = {k: v for k, v in rows.items() if v is not None}

        if rows:
            # .T makes the DICT KEYS the index: "Overall", "vs RHB",
            # "vs LHB". That label IS the data — it's the only thing
            # saying which platoon side each row describes, and this is
            # where you read what a pitcher allows to lefties vs righties.
            #
            # reset_index() turns it into a real "Split" COLUMN, which it
            # has to be: _base_styler calls .hide(axis="index"), so
            # anything left in the index is dropped before rendering.
            # That is why the labels disappeared — and why toggling
            # st.dataframe's hide_index did nothing to bring them back.
            #
            # Rendered as HTML rather than st.dataframe so the Split
            # column can be genuinely sticky while the stats scroll under
            # it. st.dataframe is canvas-drawn and CSS cannot reach it.
            full_df = pd.DataFrame(rows).T.reset_index().rename(
                columns={"index": "Split"})

            # THE DENOMINATOR RIDES WITH THE RATES.
            #
            # get_pitcher_advanced_splits already returns _games and it
            # was never rendered — the table showed BA and SLG with no
            # way to see what they were computed over. Season-only, that
            # was survivable. With a Last-game option it is not: one
            # start is roughly 25 batters faced, and .400 against on one
            # night sits in the same column, same font, as a .240 over
            # 700 at-bats.
            #
            # G goes second, immediately after Split, because a
            # denominator read AFTER the number it qualifies has already
            # done its damage. IP was always there and stays — G is the
            # cheaper read for "how thin is this".
            if "_games" in full_df.columns:
                full_df = full_df.rename(columns={"_games": "G"})
            else:
                full_df["G"] = None
            stats_cols = ["Split", "G", "IP", "BA", "SLG", "ISO", "WHIP", "HR", "HR/9"]
            strikes_cols = ["Split", "G", "BB%", "Whiff%", "K%", "Putaway%", "SwStr%", "K/9", "1stPS%", "Meatball%"]

            # A THIN WINDOW SAYS SO, ABOVE THE TABLE.
            #
            # Not a disclaimer for its own sake: THIN_WINDOWS is defined
            # in recency_windows next to the slicing itself, so the list
            # of windows that need this warning cannot drift away from
            # the list of windows that exist. The platoon rows are called
            # out separately because they are the sharpest case — a
            # starter can face three lefties in a game, and "vs LHB" over
            # three at-bats is not a split, it is an anecdote.
            from engines.recency_windows import THIN_WINDOWS
            if _splits_window in THIN_WINDOWS:
                _g = full_df.loc[full_df["Split"] == "Overall", "G"]
                _gn = int(_g.iloc[0]) if len(_g) and pd.notna(_g.iloc[0]) else 0
                st.markdown(
                    f'<div style="color:{COLOR["warn"]}; font-size:var(--lc-text-tiny); '
                    f'margin-bottom:var(--lc-space-xs);">'
                    f'Small sample \u2014 {_sw_label} is {_gn} game'
                    f'{"" if _gn == 1 else "s"} of real data, not a rate to lean on. '
                    f'The platoon rows are thinner still.</div>',
                    unsafe_allow_html=True)
            g1, g2 = st.columns(2)
            # NEITHER OF THESE TABLES HAD A FORMAT CALL.
            #
            # So both inherited style_stat_table's blanket precision of 2,
            # and the two things wrong with that are opposite: BA, SLG and
            # ISO are .000-scale rates that printed as .25 next to a
            # lineup card showing .250, while G and HR are COUNTS that
            # printed as 12.00 and 3.00. G in particular exists to tell
            # the reader how thin the window is — a sample size with two
            # decimals on it reads like a rate.
            _stats_df = full_df[stats_cols]
            _strikes_df = full_df[strikes_cols]
            with g1:
                with card("stats_table"):
                    st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">STATS</div>', unsafe_allow_html=True)
                    render_html_table(
                        style_stat_table(_stats_df, favor_high=["BA", "SLG", "ISO", "HR", "HR/9"], favor_low=["WHIP"], gradient=True)
                        .format(stat_formats(_stats_df), na_rep="N/A"),
                        key="splits_stats",
                    )
            with g2:
                with card("strikes_table"):
                    st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">STRIKES</div>', unsafe_allow_html=True)
                    render_html_table(
                        style_stat_table(_strikes_df, favor_low=["BB%", "Whiff%", "K%", "Putaway%", "SwStr%", "K/9", "Meatball%"], favor_high=["1stPS%"], gradient=True)
                        .format(stat_formats(_strikes_df), na_rep="N/A"),
                        key="splits_strikes",
                    )
            st.caption("Computed by this app directly from raw Statcast pitch data \u2014 see get_pitcher_advanced_splits() for exact definitions.")

            # -------------------------------------------------
            # HR VULNERABILITY (ALLOWED)
            #
            # These have been computed on every pitcher all along and
            # displayed nowhere: _compute_batted_ball_metrics runs on the
            # pitcher's OWN rows inside get_pitcher_statcast, so Brl %,
            # HH %, FB %, HRWindow % and EV90 there already describe the
            # contact hitters made AGAINST him. The pitcher half of the
            # HR model was invisible despite the numbers existing.
            #
            # Every value here is bad-for-the-pitcher when high, so the
            # whole card is favor_low — the opposite of the STATS card
            # above, where the same names mean the pitcher's own output.
            # -------------------------------------------------
            _hv = {
                "Brl% Allowed": pitcher_data.get("Brl % Allowed"),
                "HH% Allowed": pitcher_data.get("HH % Allowed"),
                "FB% Allowed": pitcher_data.get("FB % Allowed"),
                "FB95% Allowed": pitcher_data.get("FB95 % Allowed"),
                "HRWindow% Allowed": pitcher_data.get("HRWindow % Allowed"),
                # The trajectories he gives up that leave ANY park. The
                # strictest column on this card: a pitcher with a number
                # here is surrendering contact that no building holds.
                "Clears% Allowed": pitcher_data.get("ClearsAnywhere % Allowed"),
                "EV90 Allowed": pitcher_data.get("EV90 Allowed"),
                "HR Allowed": pitcher_data.get("HR Allowed"),
                "xHR Allowed": pitcher_data.get("xHR Allowed"),
                "xHR Gap": pitcher_data.get("xHR Gap Allowed"),
            }
            if any(v is not None for v in _hv.values()):
                with card("hr_vuln_table"):
                    st.markdown(
                        f'<div class="pf-card-title" style="color:{COLOR["gold"]};">'
                        f'HR VULNERABILITY (ALLOWED)</div>', unsafe_allow_html=True)
                    # "Season" as a real column, not an index — see the
                    # splits note above: _base_styler hides the index, so
                    # an index-only label never renders.
                    _hv_df = pd.DataFrame([{"Span": "Season", **_hv}])
                    render_html_table(
                        # Graded against the LEAGUE, not within the row.
                        #
                        # style_stat_table ranks a column against the other
                        # rows in the same table — and this table has one
                        # row, so every cell came out the same flat shade.
                        # style_vs_league compares each value to where it
                        # sits among all qualified pitchers (deciles built
                        # nightly by build_pitcher_allowed_percentiles).
                        #
                        # No favor_low: this card is read from the BATTER's
                        # side, so a pitcher allowing MORE hard contact
                        # than the league grades as the better target.
                        # Columns the league file doesn't cover render
                        # plain rather than falsely graded.
                        style_vs_league(_hv_df).format({
                            "Brl% Allowed": "{:.1f}", "HH% Allowed": "{:.1f}",
                            "FB% Allowed": "{:.1f}", "FB95% Allowed": "{:.1f}",
                            "HRWindow% Allowed": "{:.1f}",
                            "Clears% Allowed": "{:.2f}",
                            "EV90 Allowed": "{:.1f}",
                            # Counting stat — no decimals.
                            "HR Allowed": "{:.0f}",
                            # Expected values carry one decimal because a
                            # fractional expectation is the point.
                            "xHR Allowed": "{:.1f}", "xHR Gap": "{:+.1f}",
                        }, na_rep="N/A"),
                        key="hr_vuln",
                    )
                    st.caption(
                        "Contact allowed, from this pitcher's own Statcast rows. "
                        "HRWindow% Allowed is launch angle 20-40 \u2014 the home-run "
                        "band, not the 8-32 sweet spot. xHR Gap = expected home runs "
                        "allowed minus actual: a POSITIVE gap means he's been giving "
                        "up home-run trajectories that stayed in the park, and that "
                        "luck tends to run out. Park-neutral, so tonight's venue is "
                        "not baked in."
                    )
        else:
            st.info("No split data available for this pitcher yet.")

        # -------------------------------------------------
        # DENSE LINEUP TABLE \u2014 percentiles, progress bars,
        # matchup/edge tags, confidence \u2014 all from real data
        # -------------------------------------------------
        if arsenal:
            with card("arsenal_pills"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Pitcher\'s arsenal (overall usage)</div>', unsafe_allow_html=True)
                badges_html = '<div style="display:flex; gap:8px; flex-wrap:wrap;">'
                for pt, usage in sorted(arsenal.items(), key=lambda x: -x[1]):
                    c = pitch_color(pt)
                    badges_html += (
                        f'<div style="padding:var(--lc-space-sm) var(--lc-space-lg); border-radius:var(--lc-radius-md); background:{c}22; '
                        f'border:1px solid {c}66; color:{c}; font-weight:700; font-size:var(--lc-text-body); '
                        f'font-family:\'JetBrains Mono\',monospace;">{pitch_name(pt)} {usage:.0f}%</div>'
                    )
                badges_html += '</div>'
                st.markdown(badges_html, unsafe_allow_html=True)

        table_rows = []
        with card("lineup"):
            st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">{opposing_team} Lineup</div><div class="pf-card-subtitle" style="color:{COLOR["text_muted"]};">vs {selected_pitcher_name}</div>', unsafe_allow_html=True)

            if not ranked:
                st.info(f"No lineup data available for {opposing_team} right now.")
            else:
                filt_col, sort_col, window_col = st.columns([1, 1, 1])
                with filt_col:
                    bats_present = sorted(set(r["bats"] for r in ranked if r["bats"] in ("R", "L", "S")))
                    bats_filter = st.segmented_control(
                        "Bats", ["All"] + bats_present, default="All", key="lineup_bats_filter"
                    )
                with sort_col:
                    sort_choice = st.selectbox(
                        # "Batting Order" first and default: when MLB has
                        # posted a real lineup, the natural way to read it
                        # is 1 through 9. Ranking by score buried the
                        # leadoff hitter in the middle of the table and
                        # made the card harder to scan against the actual
                        # lineup card. Every analytic sort is still one
                        # click away.
                        "Sort by", ["Batting Order", "SLAM", "HR Edge", "HR Score",
                                    "Hit Score", "ΔEV", "ΔHH%", "xwOBA", "xSLG", "ISO", "Brl%",
                                    "Brl/PA", "HH%", "AvgEV", "EV90", "HRWindow%", "HRIntent",
                                    "HRThreat", "FB95%", "Clears%"],
                        key="lineup_sort_by"
                    )
                with window_col:
                    # Same control now also sits above Vs Top 3 Pitches;
                    # both drive one shared value. See _window_control.
                    window_choice = _window_control(
                        "lineup_window_top",
                        help=(
                            "PA windows are the honest ones for power: HR rate "
                            "needs ~170 PA and ISO ~160 AB, and 25 games is only "
                            "~110 PA. Games windows vary with playing time \u2014 a "
                            "platoon bat's 50 games is not a regular's 50 games. "
                            "A window longer than a hitter has played returns his "
                            "whole season under the longer label, and the parquet "
                            "only holds this season."
                        ),
                    )
                # Each label maps to a (window, unit) pair. "unit" decides
                # what "last N" counts: games played, plate appearances, or
                # batted-ball events. Games/PA give a fuller, more stable
                # recent-form read; BBE zooms in on contact quality only.
                window_unit_map = {
                    "Season": ("season", "bbe"),
                    # l25 has always been supported by apply_window and by
                    # every OTHER window control in the app (Bullpen Board,
                    # Player of the Day, WNBA form, the grade window right
                    # above). This one list was the only place missing it.
                    # LONG WINDOWS, added 2026-08-17. ~215 PA at 50 games
                    # and ~320 at 75 for an everyday bat, which clears the
                    # HR-rate and ISO stabilisation points that a 25-game
                    # window sits under. Ask in PA when the target is a PA
                    # count — games-to-PA moves with playing time.
                    "Last 75 Games": ("l75", "games"),
                    "Last 50 Games": ("l50", "games"),
                    "Last 25 Games": ("l25", "games"),
                    "Last 15 Games": ("l15", "games"),
                    "Last 10 Games": ("l10", "games"),
                    "Last 5 Games": ("l5", "games"),
                    "Last 300 PA": ("l300", "pa"),
                    "Last 250 PA": ("l250", "pa"),
                    "Last 200 PA": ("l200", "pa"),
                    "Last 60 PA": ("l60", "pa"),
                    "Last 25 PA": ("l25", "pa"),
                    "Last 15 PA": ("l15", "pa"),
                    "Last 60 BBE": ("l60", "bbe"),
                    "Last 25 BBE": ("l25", "bbe"),
                    "Last 15 BBE": ("l15", "bbe"),
                    "Last 5 BBE": ("l5", "bbe"),
                }
                window_key, unit_key = window_unit_map[window_choice]

                filtered = ranked if not bats_filter or bats_filter == "All" else [r for r in ranked if r["bats"] == bats_filter]

                # Real windowed profile fetched ONCE per batter for the
                # selected window — both SLAM and the raw stat columns
                # (Brl%, HH%, etc.) below now come from this SAME real
                # pull, so they always agree with each other and both
                # genuinely respect the Window filter, not just SLAM.
                # Switch hitters are profiled from the side they will
                # ACTUALLY bat tonight, which the opposing starter's
                # throwing hand decides (S vs RHP means batting left).
                # Blending both sides into one number hid real platoon
                # splits — often the difference between a good matchup
                # and a bad one for the very same player.
                def _side_for(row):
                    if (row.get("bats") or "").upper() != "S":
                        return None
                    if _p_throws == "R":
                        return "L"
                    if _p_throws == "L":
                        return "R"
                    return None

                windowed_profile_cache = {
                    r["name"]: get_batter_profile_windowed(
                        r.get("id"), window=window_key, unit=unit_key,
                        stand=_side_for(r))
                    for r in filtered
                }

                # For switch hitters, also pull the OTHER side so the table
                # can show both L and R as separate rows. _side_for gives
                # tonight's side (opposite the pitcher's hand); this fetches
                # the reverse. Keyed by name; only populated for S bats.
                def _other_side(row):
                    s = _side_for(row)
                    if s == "L":
                        return "R"
                    if s == "R":
                        return "L"
                    # no probable posted (_p_throws unknown): show both sides
                    # explicitly for switch hitters so neither is hidden
                    return None
                switch_other_cache = {}
                for r in filtered:
                    if (r.get("bats") or "").upper() != "S":
                        continue
                    _os = _other_side(r)
                    if _os is None:
                        # no probable: fetch BOTH sides, neither is "tonight's"
                        switch_other_cache[r["name"]] = {
                            "L": get_batter_profile_windowed(r.get("id"), window=window_key, unit=unit_key, stand="L"),
                            "R": get_batter_profile_windowed(r.get("id"), window=window_key, unit=unit_key, stand="R"),
                        }
                    else:
                        switch_other_cache[r["name"]] = {
                            _os: get_batter_profile_windowed(r.get("id"), window=window_key, unit=unit_key, stand=_os),
                        }
                slam_cache = {name: slam_from_profile(p) for name, p in windowed_profile_cache.items()}

                # BvP joins SLAM: the SAME documented tiers HR Edge uses
                # (±15 / ±10 with PA floors — engines/edge.py). Base and
                # adjustment are both kept so the Edge breakdown can show
                # the movement, and the Matchup Edges tiers below inherit
                # the ADJUSTED number — real career ownership of this
                # starter now moves a bat between tiers.
                _name_to_id = {_rr["name"]: _rr.get("id") for _rr in ranked}
                # WARM EVERY CAREER SPLIT AT ONCE, BEFORE THE LOOP.
                #
                # bvp_component below calls career_bvp once per batter,
                # and each call is its own round-trip to MLB waiting on
                # the last — eighteen sequential requests on every render
                # of the page you spend the most time in. Daily 13 hit
                # exactly this and already fixed it; the Game Card was
                # never given the same treatment.
                #
                # Optimisation only: career_bvp still works if this never
                # runs, it just goes back to waiting eighteen times in a
                # row. Everything below reads the same cache either way.
                if pitcher_id:
                    try:
                        prefetch_career_bvp(
                            (_rr.get("id"), pitcher_id) for _rr in ranked)
                    except Exception:
                        pass
                slam_bvp_cache = {}
                for _nm, _sr in slam_cache.items():
                    _base = _sr.get("slam_score")
                    _adj, _line = 0, None
                    if _base is not None and pitcher_id and _name_to_id.get(_nm):
                        _adj, _line = bvp_component(_name_to_id[_nm], pitcher_id)
                    slam_bvp_cache[_nm] = {
                        "final": (round(max(0.0, _base + _adj), 1) if _base is not None else None),
                        "base": _base, "adj": _adj, "line": _line,
                    }

                sort_key_map = {
                    # 1 through 9 as MLB posted it. Rows without a batting
                    # order (the unconfirmed-lineup fallback) sort last
                    # rather than jumping to the top, since 0 would
                    # otherwise read as "bats first".
                    "Batting Order": lambda r: -((r.get("battingOrder") or 9999) // 100
                                                 if r.get("battingOrder") else 9999),
                    "SLAM": lambda r: slam_bvp_cache[r["name"]]["final"] or 0.0,
                    "HR Edge": lambda r: _score_num(r.get("edge")),
                    "HR Score": lambda r: _score_num(r["hr_score"]),
                    "Hit Score": lambda r: _score_num(r["hit_score"]),
                    # Off the RANKED ROW, not windowed_profile_cache — the
                    # only sort keys on this table that must not read the
                    # window. rank_batters computed these as
                    # FORM_WINDOW-minus-season (engines/form); a windowed
                    # lookup would silently sort by a different quantity
                    # than the column shows.
                    #
                    # `or 0` for the same reason as every key below: a
                    # delta is absent for a bat with no measurable recent
                    # window, and None breaks sorted(). Note that 0 is a
                    # REAL value in these columns — a hitter exactly at his
                    # own baseline — so unmeasured bats sort in among bats
                    # that genuinely did not move. That is the least-wrong
                    # option here: the alternative sinks them to the bottom
                    # of a signed column, which reads as ice cold.
                    "ΔEV": lambda r: r.get("ΔEV") or 0,
                    "ΔHH%": lambda r: r.get("ΔHH%") or 0,
                    "xwOBA": lambda r: windowed_profile_cache[r["name"]].get("xwOBA") or 0,
                    "xSLG": lambda r: windowed_profile_cache[r["name"]].get("xSLG") or 0,
                    "ISO": lambda r: windowed_profile_cache[r["name"]].get("ISO") or 0,
                    # `or 0`, not a .get default: the key now EXISTS with
                    # a None value when barrels weren't measurable, so a
                    # default never fires and sorted() would raise
                    # TypeError comparing None to float — taking out the
                    # whole lineup table. Same reasoning as Brl/PA below.
                    "Brl%": lambda r: windowed_profile_cache[r["name"]].get("Brl %") or 0,
                    # The new HR axes are sortable too — Brl/PA and
                    # HRWindow% are the two most useful ways to reorder
                    # this board for a home-run read, and neither was
                    # reachable before. `or 0` because these are None
                    # (not 0) for bats we can't measure, and None breaks
                    # the sort.
                    "Brl/PA": lambda r: windowed_profile_cache[r["name"]].get("Brl/PA") or 0,
                    # `or 0` for consistency with every other key here.
                    # HH% is not currently nullable, but a .get default is
                    # the wrong guard for a sort key regardless — it can't
                    # protect against a present-but-None value.
                    "HH%": lambda r: windowed_profile_cache[r["name"]].get("HH %") or 0,
                    # Windowed, like EV90 beside it — the two have to be
                    # read against each other and cannot be on different
                    # windows.
                    "AvgEV": lambda r: windowed_profile_cache[r["name"]].get("AvgEV") or 0,
                    "EV90": lambda r: windowed_profile_cache[r["name"]].get("EV90") or 0,
                    "HRWindow%": lambda r: windowed_profile_cache[r["name"]].get("HRWindow %") or 0,
                    "HRIntent": lambda r: windowed_profile_cache[r["name"]].get("HRIntent") or 0,
                    "HRThreat": lambda r: windowed_profile_cache[r["name"]].get("HRThreat") or 0,
                    "FB95%": lambda r: windowed_profile_cache[r["name"]].get("FB95 %") or 0,
                    "Clears%": lambda r: windowed_profile_cache[r["name"]].get("ClearsAnywhere %") or 0,
                }
                filtered = sorted(filtered, key=sort_key_map[sort_choice], reverse=True)

                if not filtered:
                    st.info(f"No batters match that Bats filter for {opposing_team}.")

                _board_idx = board_ranks()
                table_rows = []
                for r in filtered:
                    profile = windowed_profile_cache[r["name"]]
                    slam_result = slam_cache[r["name"]]
                    _sb = slam_bvp_cache[r["name"]]
                    # Keep a missing SLAM as None so the table shows "—",
                    # not 0.0 — a real 0.0 would read as a genuinely awful
                    # score and could make you fade a good hitter whose
                    # expected stats simply weren't available in this
                    # window.
                    slam = _sb["final"]
                    # Matchup tier is DERIVED from SLAM, so a missing
                    # SLAM has to blank the tier too. Feeding 0.0 into
                    # matchup_tier returned "Weak" — a fabricated read
                    # on a bat that was never measured, sitting in the
                    # same column as tiers that were. The em dash two
                    # lines up already made that call for SLAM itself.
                    tier = matchup_tier(slam) if slam is not None else None
                    r["slam_base"], r["slam_adj"] = _sb["base"], _sb["adj"]
                    conf_label, sample = confidence_tier(profile.get("BBE", 0))

                    hr_s, hit_s, k_s = r["hr_score"], r["hit_score"], r["k_score"]

                    if hr_s is None and hit_s is None and k_s is None:
                        tag_label, tag_tier = "No League Data", "neutral"
                    elif hr_s is not None and hr_s >= 20:
                        tag_label, tag_tier = f"Strong HR Target +{hr_s-10}%", "strong"
                    elif k_s is not None and k_s >= 70:
                        tag_label, tag_tier = f"K Risk -{k_s-60}%", "risk"
                    elif hit_s is not None and hit_s >= 60:
                        tag_label, tag_tier = f"Good Hit Pick +{hit_s-50}%", "good"
                    elif hr_s is not None and hit_s is not None and hr_s < 15 and hit_s < 30:
                        tag_label, tag_tier = "Avoid", "risk"
                    else:
                        tag_label, tag_tier = "Neutral", "neutral"

                    _is_switch = (r.get("bats") or "").upper() == "S"
                    _tonight = _side_for(r)  # L / R / None

                    # Primary row: tonight's matchup side (or plain side for
                    # non-switch). Carries the real scores/matchup.
                    # EVERY SWITCH-HITTER ROW SAYS WHAT IT IS.
                    #
                    # A switch hitter produces two or three rows here,
                    # because his two sides are often two different
                    # hitters and blending them hides the split that
                    # decides the matchup. The rows were not labelled
                    # well enough to tell apart:
                    #
                    #   probable posted -> "S->L" primary, "S (R)" split.
                    #     Readable.
                    #   NO probable     -> "S" primary, then "S (L)" and
                    #     "S (R)". Three rows, same name, same batting
                    #     order, different numbers — and the first one
                    #     labelled with a bare "S" that looks like a
                    #     third platoon side.
                    #
                    # The bare row is NOT a side. windowed_profile_cache
                    # builds it with stand=None, so it is every plate
                    # appearance from BOTH sides combined. Labelling it
                    # "S (L)" would have been a straight lie about which
                    # numbers those are; labelling it "S" left the reader
                    # to guess. It now says so: "S (both)".
                    #
                    # _bats_column colours any label naming a side, and
                    # "both" names none, so the combined row stays neutral
                    # while its two split siblings take platoon colours —
                    # which is the right visual hierarchy anyway.
                    if _is_switch:
                        _primary_label = (f'S\u2192{_tonight}' if _tonight
                                          else "S (both)")
                    else:
                        _primary_label = r["bats"]
                    table_rows.append(_stat_row(
                        r["name"], _primary_label, profile,
                        # Ranked nightly against the whole league, so it
                        # is read here rather than recomputed — a view
                        # cannot rank a hitter against a league it does
                        # not have.
                        # Built once for the slate and passed in — the
                        # index is one cached lookup, not one per row.
                        boards=token_text(r.get("id"), _board_idx),
                        form_pct=r.get("form_pct"), form_dir=r.get("form_dir"),
                        hr_count=r.get("hr_count"), near_hr=r.get("near_hr"),
                        l5_pa=r.get("l5_pa_per_game"),
                        avg_dist=r.get("avg_dist"),
                        dist_300=r.get("dist_300"), dist_350=r.get("dist_350"),
                        matchup=tier, slam=slam,
                        hr_edge=r.get("edge"), hr_score=r["hr_score"], hit_score=r["hit_score"],
                        # Already computed by rank_batters for every rated
                        # bat, live, off this app's own Statcast parquet —
                        # these do NOT wait on the HR Edge board being
                        # published, so they are populated on a game card
                        # hours before any board exists.
                        form_deltas={c: r.get(c) for c in form_engine.FORM_COLUMNS
                                     if r.get(c) is not None},
                        # Warmed by the prefetch above, so this is a
                        # cache hit rather than a round-trip.
                        bvp=(career_bvp_short(r.get("id"), pitcher_id)
                             if pitcher_id else ""),
                        edge_cell=edge_tag(tag_label, tag_tier),
                        edge_label=tag_label, edge_tier=tag_tier,
                        confidence=f"{conf_label} \u2014 n={sample}",
                        batting_order=r.get("battingOrder"),
                    ))

                    # Switch hitter: add row(s) for the other side(s), stats
                    # only. If a probable is posted we already showed tonight's
                    # side above and add just the reverse; if not, _tonight is
                    # None and we add both L and R explicitly.
                    if _is_switch and r["name"] in switch_other_cache:
                        for _sd, _prof in switch_other_cache[r["name"]].items():
                            if _tonight and _sd == _tonight:
                                continue  # already shown as the primary row
                            _c_lbl, _c_n = confidence_tier(_prof.get("BBE", 0))
                            table_rows.append(_stat_row(
                                r["name"], f'S ({_sd})', _prof,
                                confidence=f"{_c_lbl} \u2014 n={_c_n}",
                                edge_label="split view", edge_tier="neutral",
                                batting_order=r.get("battingOrder"),
                            ))

                display_df = pd.DataFrame(table_rows) if table_rows else None
                if display_df is not None:
                    edge_col = display_df.pop("Edge")

                    # COLUMN GROUPS — 27 columns is unusable on a phone.
                    #
                    # Not a mobile-only hack: Streamlit can't detect screen
                    # size server-side, and a CSS approach can't work here
                    # because st.dataframe draws on a canvas. So it's a
                    # user choice that works the same everywhere, and it
                    # DEFAULTS TO ALL — desktop behaviour is byte-identical
                    # unless someone picks a narrower set. The choice
                    # persists in session state, so picking "Power" once on
                    # a phone keeps it across reruns.
                    #
                    # Player/Bats/Ord lead every group: they're what tells
                    # you whose row you're reading, and losing that while
                    # scrolling sideways was the other half of the problem.
                    # Ord before Bats: the slot is what you scan for when
                    # you already know the lineup, and the hand is what you
                    # check second.
                    _ident = ["Player", "Ord", "Bats"]

                    # COLUMN ORDER, BY WHAT THE MODEL ACTUALLY WEIGHTS.
                    #
                    # Order was accidental: whatever _stat_row happened to
                    # insert first. Six volume and distance columns went in
                    # after Form and pushed Brl/PA — the single
                    # heaviest input in HR Score — out past ten others.
                    #
                    # There is a non-arbitrary answer, and it is not taste.
                    # engines/top_plays multiplies out to:
                    #
                    #   Brl/PA     28%   (POWER .40 x .70)
                    #   FB95%      18%   (CONVERGE .30 x .60)
                    #   EV90       12%   (POWER .40 x .30)
                    #   Clears%    12%   (CONVERGE .30 x .40)
                    #   HRWindow%  11%   (LAUNCH .22 x .50)
                    #   PullAir%   11%   (LAUNCH .22 x .50)
                    #
                    # So the scored inputs lead, heaviest first, and every
                    # other column follows in tiers. A reader scanning left
                    # to right is then reading the score's own reasoning in
                    # its own order rather than an accident of dict
                    # insertion.
                    #
                    # If the weights are ever refitted against the research
                    # log, THIS LIST MOVES WITH THEM — that is the point of
                    # deriving it from them rather than typing an order
                    # someone liked.
                    # COLUMN ORDER.
                    #
                    # The head of this list is the OWNER'S reading order,
                    # given explicitly: identity, the model's verdicts, the
                    # slash line, then contact quality. It is how a
                    # baseball person scans a row, and it is deliberately
                    # NOT the model's internal order — Brl/PA is 28% of HR
                    # Score and sits behind four outcome stats here. That
                    # is a real trade, made on purpose: this table is read
                    # by a person every night, and matching how he reads
                    # beats matching how the score computes.
                    #
                    # Everything after PullBrl% is arranged here, and the
                    # tiers below say why.
                    _COL_ORDER = (
                        # --- given, in this order -----------------------
                        # ORDERED BY WHAT EACH COLUMN CHECKS, not by what
                        # category it belongs to.
                        #
                        # Two columns side by side are read as a PAIR
                        # whether or not that was intended, so adjacency
                        # is the actual tool here. Every neighbour below
                        # is the thing that qualifies the column before
                        # it.
                        #
                        # --- who, and does the model like him -----------
                        # HR Edge beside HR Score because THE GAP IS THE
                        # READ. Close together, the hitter is the pick.
                        # Edge far above Score, the SPOT is the pick —
                        # and a spot-driven bat is the one that
                        # evaporates on a lineup change or a wind flip.
                        ["HR Edge", "HR Score", "Hit Score", "SLAM", "Boards",
                         # Career vs tonight's starter — a verdict about
                         # THIS matchup, so it sits with the other
                         # verdicts rather than in the rate run.
                         "BvP",

                         # --- is he that hitter RIGHT NOW ---------------
                         # Form beside its own magnitude. The percentile
                         # says he is hotter than 96 percent of the
                         # league; the delta says by how much, in mph.
                         # 96% with +1.7 is a real
                         # move and 96% with +0.2 is a technicality, and
                         # nobody can tell those apart with twenty columns
                         # in between. Only dEV rides along: it is the
                         # better-behaved input (measured band +/-7.3%
                         # against dHH%'s +/-48%), so it is the one that
                         # means something at a glance.
                         "Form", "\u0394EV",

                         # --- how much evidence is any of this ----------
                         # PA is the denominator under every rate to its
                         # right, and it was buried with the volume stats.
                         # A .300 ISO on 65 PA and on 543 PA are not the
                         # same claim. It sits here as the veto, before
                         # the numbers it qualifies rather than after.
                         #
                         # Pitches and BIP flank it because PA alone is
                         # the WRONG denominator for most of this table.
                         # Brl%, HH%, FB%, GB%, LD%, SweetSpot%,
                         # HRWindow%, PullAir%, FB95% and Clears% are all
                         # per BALL IN PLAY, and a hitter with 200 PA can
                         # have 90 or 140 balls in play depending on how
                         # much he walks and whiffs. Reading those rates
                         # against PA overstates the sample by a third.
                         # Pitches is the widest and is what SwStr% and
                         # the whiff numbers actually rest on.
                         #
                         # Widening left to right, so the eye reads the
                         # three as one scale rather than three unrelated
                         # counts.
                         "Pitches", "PA", "BIP",

                         # --- the power claim: actual, then expected ----
                         # ISO first because it is SLG minus BA — power
                         # with the singles stripped out — and BA last
                         # because a hitter can bat .320 entirely on
                         # singles, which makes it the weakest column on a
                         # home-run board. ISO next to xSLG is deliberate:
                         # the gap between what he HAS slugged and what he
                         # was EXPECTED to is the luck still owed to him.
                         "ISO", "xSLG", "xwOBA", "BA",

                         # --- the two least redundant power inputs ------
                         # Brl/PA is 28% of HR Score by itself, and Brl%
                         # further right is the same event over a
                         # different denominator. Clears% is the one
                         # number nothing else here duplicates: league
                         # median is 0.00, so over half of qualified
                         # hitters have NEVER put a ball on a trajectory
                         # that leaves every park. A column earns its
                         # place by disagreeing, and this is the one most
                         # able to.
                         "Brl/PA", "Clears%",

                         # --- cashed against owed -----------------------
                         # Read right here, while you are deciding whether
                         # the power above is real. 3 homers against 12
                         # near misses is a hitter the ball is not falling
                         # for; 12 against 3 has already been paid.
                         "HR", "NearHR",

                         # --- contact quality, as given -----------------
                         "Brl%", "HH%", "FB%", "GB%", "LD%", "AvgEV",
                         "PullBrl%"]

                        # --- 1. THE REST OF WHAT HR SCORE IS MADE OF ----
                        # Heaviest first, from engines/top_plays:
                        #   FB95% 18% · EV90 12% · HRWindow% 11%
                        #   PullAir% 11%
                        # (Brl/PA 28% and Clears% 12% are up in the head,
                        #  ahead of the contact run — see the note there.)
                        # They lead the tail because when a reader keeps
                        # scrolling past the slash line, this is the next
                        # thing worth their attention — and if the weights
                        # are ever refitted against the research log, this
                        # run reorders with them.
                        + ["FB95%", "EV90", "HRWindow%", "PullAir%"]

                        # --- 2. THE COMPOSITE SECOND OPINIONS -----------
                        # Built from different inputs than HR Score, so
                        # they earn their place by DISAGREEING with it.
                        # Directly after the inputs, because that is where
                        # a disagreement is legible.
                        + ["HRThreat", "HRIntent", "Blast%", "SweetSpot%",
                           "MaxEV"]

                        # --- 3. OUTCOMES, AND THE PAIR ------------------
                        # HR next to NearHR always: 3 homers against 12
                        # near misses is a different hitter from 12 against
                        # 3, and separating them destroys the only
                        # comparison NearHR exists for.
                        + ["HR/FB", "SLG", "OPS"]

                        # --- 4. VOLUME AND DISTANCE --------------------
                        # Descriptive, and last of the real stats. L5 PA/G
                        # is the exception worth knowing about: everything
                        # above is a RATE and this is the volume those
                        # rates get applied to, so it is the first thing to
                        # check when two bats look identical.
                        + ["L5 PA/G", "AvgDist", "300+", "350+", "AB"]

                        # --- 5. THE CHECKABLE FORM DELTAS --------------
                        # Dead last on purpose. They are plain subtraction
                        # against Savant — the verifiable version of the
                        # Form column at the front — so they belong where
                        # someone auditing a number goes looking, not in
                        # the glance path.
                        + ["\u0394HH%"]
                    )

                    def _ordered(cols):
                        """_COL_ORDER first, then anything it forgot.

                        A column missing from the list must still RENDER —
                        dropping one silently is how a stat disappears from
                        the site and nobody notices for a month.
                        """
                        known = [c for c in _COL_ORDER if c in cols]
                        rest = [c for c in cols if c not in _COL_ORDER
                                and c not in _ident]
                        return _ident + known + rest

                    _groups = {
                        "All": None,
                        # CAPPED AT 14 (see tests/test_column_groups) and it
                        # was already at 14, so the two new columns had to
                        # displace two. What went, and why:
                        #
                        #   MaxEV     the comment on its own row calls it
                        #             interest only — it's a sample of one.
                        #             EV90 is the scored power ceiling and
                        #             stays.
                        #   PullBrl%  overlaps PullAir% and Brl% almost
                        #             entirely, and both of those stay.
                        #
                        # Neither is gone: "All" still shows every column,
                        # and both remain sortable. This group is the
                        # narrow phone view, not the full table.
                        "Power": _ident + ["HR Edge", "HR Score", "HRThreat",
                                           "Brl%", "Brl/PA", "Clears%",
                                           "EV90", "HRWindow%", "HRIntent",
                                           "PullAir%", "Blast%"],
                        "Contact": _ident + ["Hit Score", "SLAM", "BA", "xwOBA", "xSLG",
                                             "ISO", "HH%", "LD%", "FB%", "GB%",
                                             "SweetSpot%"],
                        # Form and AvgEV land HERE rather than in Power,
                        # which is already at the documented 14 cap with
                        # every slot argued for above. Quick had room, and
                        # it is the group that gets used on a phone — the
                        # two questions "is he hot right now" and "how hard
                        # does he hit it" are exactly what an at-a-glance
                        # read wants. Both are in "All" regardless, which
                        # is the default.
                        "Quick": _ident + ["HR Edge", "HR Score", "Hit Score", "SLAM",
                                           "ΔEV", "ΔHH%", "xwOBA", "Brl/PA", "HH%", "AvgEV"],
                    }
                    display_df = display_df[
                        [c for c in _ordered(list(display_df.columns))
                         if c in display_df.columns]]
                    _grp = st.segmented_control(
                        "Columns", list(_groups),
                        default="All", key="lineup_col_group",
                        label_visibility="collapsed",
                    ) or "All"

                    _table_df = display_df.drop(
                        columns=["Matchup", "Confidence", "EdgeLabel", "EdgeTier"])
                    _keep = _groups.get(_grp)
                    if _keep:
                        # Intersect rather than reindex: a column can be
                        # absent (no Statcast rows for anyone in the
                        # lineup), and asking for a missing one would
                        # produce an all-NaN column that looks like real
                        # missing data instead of a column we never had.
                        _table_df = _table_df[[c for c in _keep if c in _table_df.columns]]

                    # (The st.column_config pinned-Player block that used to
                    # sit here went with the st.dataframe call below —
                    # render_html_table pins the first column in CSS.)
                    styled = style_stat_table(
                        _table_df,
                        # AvgEV and Form both have ABSOLUTE cut points in
                        # styles/stat_scales.py already (the HR Edge board
                        # colours them from the same entries), so a given
                        # number takes the same colour on both boards and
                        # does not change tier when a filter moves.
                        favor_high=["SLAM", "BA", "xwOBA", "xSLG", "ISO", "HR/FB", "Brl%", "Brl/PA", "HH%", "AvgEV", "EV90", "MaxEV", "LD%", "FB%", "SweetSpot%", "HRWindow%", "PullAir%", "PullBrl%", "Blast%", "HRIntent", "HRThreat", "FB95%", "Clears%", "ΔEV", "ΔHH%",
                                    "HR", "NearHR", "L5 PA/G", "AvgDist",
                                    "300+", "350+"],
                        # HR Edge / HR Score / Hit Score are deliberately
                        # NOT in favor_high: score_bar already encodes each
                        # one as a filled bar, and a gradient cell behind
                        # the bar is a SECOND encoding of the same number.
                        # The two colours fought each other and the result
                        # read as mud — neither the bar length nor the cell
                        # shade was legible.
                        favor_low=["GB%", "SwStr%"],
                        gradient=True,
                    )
                    # EVERY numeric column needs an entry here. Anything
                    # missing falls through to style_stat_table's global
                    # .format(precision=2), which is why the new columns
                    # first rendered as 104.00 and 91.70 while their
                    # neighbours showed 104.0 and 91.7.
                    styled = styled.format({
                        "Ord": "{:.0f}",
                        "SLAM": "{:.1f}", "BA": "{:.3f}", "xwOBA": "{:.3f}", "xSLG": "{:.3f}",
                        "ISO": "{:.3f}", "HR/FB": "{:.1f}",
                        "Brl%": "{:.1f}", "HH%": "{:.1f}", "LD%": "{:.1f}",
                        "FB%": "{:.1f}", "GB%": "{:.1f}", "SweetSpot%": "{:.1f}", "PullAir%": "{:.1f}",
                        "PullBrl%": "{:.1f}", "Blast%": "{:.1f}", "SwStr%": "{:.1f}",
                        # Rates: one decimal, matching Brl%/HH% beside them.
                        "Brl/PA": "{:.1f}", "HRWindow%": "{:.1f}",
                        # Exit velocities read as mph — one decimal is how
                        # Statcast publishes them.
                        "AvgEV": "{:.1f}", "EV90": "{:.1f}", "MaxEV": "{:.1f}",
                        # Counts render whole; a hitter cannot have 7.0
                        # home runs. AvgDist too — a foot of precision on
                        # a projected landing point is false precision.
                        "HR": "{:.0f}", "NearHR": "{:.0f}",
                        # SAMPLE SIZES, WHOLE. Without these three the
                        # global .format(precision=2) in style_stat_table
                        # renders them as 412.00 / 187.00 / 96.00 — the
                        # exact failure the comment at the top of this
                        # dict describes, and the one that caught PA
                        # printing as 543.000000 the last time it was
                        # briefly on this table.
                        "Pitches": "{:.0f}", "PA": "{:.0f}", "BIP": "{:.0f}",
                        "300+": "{:.0f}", "350+": "{:.0f}",
                        "AvgDist": "{:.0f}", "L5 PA/G": "{:.1f}",
                        # SIGNED, always. These are the only columns on
                        # this table where the sign IS the reading — a
                        # bare "1.8" in a delta column is unreadable
                        # without knowing which way it went, and 0.0 is a
                        # real measured value here rather than a missing
                        # one. Same {:+.1f} the Matchup and Context
                        # adjustments use on the HR Edge board.
                        "ΔEV": "{:+.1f}", "ΔHH%": "{:+.1f}",
                        # 0-100 composite, formatted like HR/Hit Score.
                        "HRIntent": "{:.0f}", "HRThreat": "{:.0f}",
                        "FB95%": "{:.1f}",
                        # Two decimals, not one. League average clears-anywhere
                        # contact is a fraction of a percent, so {:.1f} would
                        # print 0.0 for most of the league and throw away the
                        # only resolution this column has.
                        "Clears%": "{:.2f}",
                        # Inline filled bars, same three columns that used
                        # st.column_config.ProgressColumn before this table
                        # moved off st.dataframe. score_bar returns markup
                        # and pandas doesn't escape formatter output, so
                        # the bar renders where the number used to.
                        # Handedness as a chip, not a bare letter. Most of
                        # the platoon logic in this app turns on this
                        # column, and an L or R sitting in a dense row of
                        # numbers reads as just another character.
                        "Bats": bats_chip(),
                        "HR Edge": score_bar("gold"),
                        "HR Score": score_bar("stat_high"),
                        "Hit Score": score_bar("warn"),
                    }, na_rep="N/A")
                    # FORM IS TEXT ("86% \u2191"), so the numeric styler
                    # skipped it and it rendered in plain type beside
                    # twenty graded columns — which reads as "this one
                    # does not matter". grade_text_column grades on the
                    # leading number against the Form scale in
                    # stat_scales; the arrow is decoration.
                    styled = grade_text_column(styled, "Form",
                                               scale_key="Form", gradient=True)
                    # LAST TABLE OFF st.dataframe.
                    #
                    # This one held out longest because its HR Edge / HR
                    # Score / Hit Score columns used
                    # st.column_config.ProgressColumn for inline bars. But
                    # Streamlit's grid has drag-to-reorder built in with no
                    # way to switch it off (streamlit#11222), so on a phone
                    # a scroll gesture scattered the columns of the single
                    # table people spend the most time in.
                    #
                    # The bars did NOT have to be sacrificed: score_bar()
                    # in table_style renders the same filled bar as markup
                    # in the cell, so this is a straight win over the
                    # widget rather than a trade.
                    #
                    # The first column stays put either way:
                    # render_html_table makes it sticky in CSS, which works
                    # on touch where the grid's pinning did not.
                    # Colour key with the table. The lineup has both tier-
                    # coloured cells AND tier-coloured bars, so without it a
                    # reader has to infer that gold means "good" — and on
                    # the pitcher tables above, colour reads the other way.
                    tier_legend(favor_note="Higher is better for the BATTER \u2014 "
                                           "colour is his grade in that column.")
                    render_html_table(styled, key="gc_lineup")
                    # SAY THE EXCEPTION OUT LOUD.
                    #
                    # Every other column on this table moves when the
                    # Window control moves. The two Form deltas do not,
                    # and a reader who set Window to Last 5 Games and
                    # watched two columns sit still would reasonably
                    # conclude they were stale or broken. They are
                    # neither: a delta is a comparison BETWEEN two
                    # windows and cannot be pinned to one. Rule 20 in
                    # reverse — a signal the reader can't interpret is
                    # not a signal, so the definition ships with it.
                    st.caption(
                        f"{form_engine.FORM_COLUMNS[0]} and {form_engine.FORM_COLUMNS[1]} "
                        "are FORM, and they are plain subtraction: each hitter's last "
                        f"{form_engine.FORM_WINDOW.lstrip('l')} batted balls minus his "
                        "OWN season, in mph and in percentage points. Nothing is scaled "
                        "or ranked \u2014 +1.8 means his exit velocity is 1.8 mph above "
                        "where he has been all year, and you can check it against "
                        "Savant. That makes them the opposite of HR Score and HRThreat "
                        "beside them, which say where he sits among OTHER hitters. "
                        "They are also the only columns here that do NOT follow the "
                        "Window control, because a comparison between two windows "
                        "cannot be pinned to one: set Window to the same span and "
                        "every hitter would read 0.0. They are computed live, so they "
                        "fill in whether or not the HR Edge board has published. AvgEV "
                        "and every other stat column do follow the Window."
                    )
                    if not league_data_available:
                        st.caption("HR Score / Hit Score / K Score show N/A above because Baseball Savant's live percentile rankings aren't reachable right now (see warning above) \u2014 not because these players lack power or contact skill.")

                    # -------------------------------------------------
                    # WEAK SPOT vs THIS LINEUP — the alignment view:
                    # tonight's starter's per-slot weakness mapped onto
                    # the actual hitters batting those slots. This is the
                    # bettable read: a real, well-sampled weak slot that
                    # a dangerous hitter is sitting in tonight.
                    # -------------------------------------------------
                    if pitcher_id:
                        _wsl = get_weak_spots(pitcher_id)
                        _slot_map = {s["slot"]: s for s in _wsl.get("slots", [])}
                        # batters is in real batting order; index+1 = slot.
                        _order = [b for b in batters][:9]
                        if _slot_map and _order:
                            # SORTED BY LEAK, NOT BY BATTING ORDER.
                            #
                            # This is the change that makes the panel worth
                            # reading. Nine slots listed 1 through 9 is a
                            # roster printout — the reader scans all nine and
                            # holds them in their head. Sorted by damage the
                            # TOP ROWS ARE THE ANSWER.
                            #
                            # slot_rows also drops slots below the sample
                            # floor entirely rather than rendering an empty
                            # track, so a short list means "these are the
                            # ones we can actually measure" instead of
                            # "something is missing".
                            _align_rows = []
                            for _slot, _xslg, _bbe, _b in slot_rows(
                                    _wsl.get("slots", []), lineup=_order):
                                if _b is None:
                                    continue
                                _align_rows.append({
                                    "slot": _slot,
                                    "name": _b.get("name", "\u2014"),
                                    "bats": _b.get("bats", ""),
                                    "xslg": _xslg,
                                    "bbe": _bbe or 0,
                                    # Weak = he gets hit here AND the bucket
                                    # cleared its sample floor. Both, because
                                    # a thin bucket can show any number.
                                    "weak": _xslg is not None and _xslg >= XSLG_HOT,
                                })
                            if any(r["xslg"] is not None for r in _align_rows):
                                st.markdown(
                                    f'<div class="pf-card-title" style="color:{COLOR["gold"]}; '
                                    f'margin-top:var(--lc-space-lg);">Weak spot vs this lineup</div>'
                                    f'<div class="pf-card-subtitle">{selected_pitcher_name}\u2019s xSLG '
                                    f'allowed by batting slot, mapped to tonight\u2019s hitters, '
                                    f'ORDERED BY WHERE HE LEAKS \u2014 the top rows are the read. '
                                    f'Green = a real, well-sampled slot where he gets hit and a '
                                    f'live bat is sitting. A slot line partly reflects WHICH '
                                    f'hitters have batted there across his starts, not the pitcher '
                                    f'alone \u2014 which is exactly why it is shown against '
                                    f'tonight\u2019s order rather than on its own. Slots below the '
                                    f'sample floor are omitted.'
                                    f'</div>',
                                    unsafe_allow_html=True,
                                )
                                _hdr = (
                                    f'<tr style="font-size:var(--lc-text-tiny); color:{COLOR["text"]}; opacity:0.55;">'
                                    f'<td style="padding:var(--lc-space-xs) var(--lc-space-md);">#</td>'
                                    f'<td style="padding:var(--lc-space-xs) var(--lc-space-md);">Hitter</td>'
                                    f'<td style="padding:var(--lc-space-xs) var(--lc-space-md);">B</td>'
                                    f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); text-align:right;">xSLG vs slot</td>'
                                    f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); text-align:right;">n</td></tr>'
                                )
                                _body = ""
                                for _r in _align_rows:
                                    _bg = (f'background:{COLOR["stat_high"]}22;'
                                           if _r["weak"] else "")
                                    if _r["xslg"] is None:
                                        _xcell = f'<span style="color:{COLOR["text"]}; opacity:0.4;">\u2014</span>'
                                    else:
                                        _c = (COLOR["error"] if _r["xslg"] >= XSLG_HOT
                                              else COLOR["stat_high"] if _r["xslg"] <= XSLG_COLD
                                              else COLOR["warn"])
                                        _xcell = f'<span style="font-weight:800; color:{_c};">{_r["xslg"]:.3f}</span>'
                                    _body += (
                                        f'<tr style="{_bg} font-size:var(--lc-text-caption);">'
                                        f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); color:{COLOR["text"]}; opacity:0.6;">{_r["slot"]}</td>'
                                        f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); color:{COLOR["text"]}; font-weight:600;">{_r["name"]}'
                                        + (' \U0001F3AF' if _r["weak"] else '') + '</td>'
                                        f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); color:{COLOR["text"]}; opacity:0.6;">{_r["bats"]}</td>'
                                        f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); text-align:right;">{_xcell}</td>'
                                        f'<td style="padding:var(--lc-space-xs) var(--lc-space-md); text-align:right; color:{COLOR["text"]}; opacity:0.45; font-size:var(--lc-text-tiny);">{_r["bbe"]}</td>'
                                        f'</tr>'
                                    )
                                st.markdown(
                                    f'<table style="width:100%; border-collapse:collapse;">'
                                    f'{_hdr}{_body}</table>',
                                    unsafe_allow_html=True,
                                )
                                _weak_names = [r["name"] for r in _align_rows if r["weak"]]
                                if _weak_names:
                                    st.caption(
                                        "\U0001F3AF Target spots tonight: " + ", ".join(_weak_names)
                                        + " \u2014 real, well-sampled slots where this starter gets hit. "
                                        "Still cross-check the hitter\u2019s own form above; this flags "
                                        "the matchup, not a lock."
                                    )
                                else:
                                    st.caption(
                                        "No slot clears both the damage threshold and the sample "
                                        "floor against this lineup \u2014 no standout target spot tonight."
                                    )

                    if league_data_available:
                        st.caption("HR Score / Hit Score are this app's own composite scores from real, live MLB percentile rankings (baseballsavant.mlb.com); HR Score now includes the Exit Velocity percentile. HR Edge = HR Score + the matchup layer (BvP \u00b115, Zone Fit \u00b115, Bullpen \u00b110 \u2014 engines/edge.py has every tier). Not calibrated predictive probabilities.")
                        # Named qualification badges — the "why upside"
                        # read, from thresholds documented in
                        # engines/pick_badges.py. Top 5 by Edge only, so
                        # it stays a highlight reel rather than a second
                        # copy of the table.
                        _badge_pool = sorted(
                            [r for r in filtered if r.get("edge") is not None],
                            key=lambda r: -(r.get("edge") or 0),
                        )
                        # DELIBERATELY NOT LOGGING hr_edge HERE ANY MORE.
                        #
                        # This used to write the top 5 bats from THIS ONE
                        # GAME to the "hr_edge" calibration board every
                        # time a game card rendered. calibration_picks.py
                        # now writes the SLATE-WIDE top 5 to that same
                        # board key from CI.
                        #
                        # Two writers, one key, same date. Opening a game
                        # card overwrote the real slate board with one
                        # game's bats — and neither is graded early in
                        # the day, so which one survived the merge was
                        # effectively arbitrary. The hr_edge record would
                        # have been sometimes the model's actual board and
                        # sometimes whichever matchup you happened to
                        # click, with no way to tell them apart after the
                        # fact. That silently invalidates the exact
                        # measurement the slate board was built to make
                        # honest.
                        #
                        # engines/hr_edge_board.py owns this board now.
                        # Browsing the site can no longer alter the record.

                        _any_badges = False
                        for _br in _badge_pool[:5]:
                            _bd, _why = compute_badges(
                                _br, windowed_profile_cache.get(_br["name"], {}),
                                pitcher_data, park.get("park_factor"),
                                game.get("weather_wind"),
                            )
                            if _bd:
                                if not _any_badges:
                                    st.markdown(
                                        f'<div class="pf-card-title" style="color:{COLOR["gold"]}; '
                                        f'margin-top:var(--lc-space-md);">Why these bats</div>',
                                        unsafe_allow_html=True,
                                    )
                                    _any_badges = True
                                render_badge_row(st, COLOR, _bd, _why, _br["name"],
                                                 _br.get("hr_score"), _br.get("edge"))

                        with st.expander("\U0001F9EE Edge breakdown \u2014 why each bat moved"):
                            for _r in filtered:
                                if _r.get("edge") is None:
                                    continue
                                _parts = []
                                if _r.get("bvp_adj"):
                                    _parts.append(f'BvP {_r["bvp_adj"]:+d} ({_r.get("bvp_line")})')
                                elif _r.get("bvp_line"):
                                    _parts.append(f'BvP 0 ({_r.get("bvp_line")})')
                                if _r.get("zone_adj"):
                                    _parts.append(f'Zone {_r["zone_adj"]:+d} ({_r.get("zone_note")})')
                                elif _r.get("zone_note"):
                                    _parts.append(f'Zone 0 ({_r.get("zone_note")})')
                                if _r.get("pen_note"):
                                    _parts.append(f'Pen {_r.get("pen_adj", 0):+d} ({_r.get("pen_note")})')
                                _slam_bit = ""
                                if _r.get("slam_adj"):
                                    _slam_bit = (f'SLAM {_r.get("slam_base")} \u2192 '
                                                 f'{round(max(0.0, (_r.get("slam_base") or 0) + _r["slam_adj"]), 1)} '
                                                 f'(BvP {_r["slam_adj"]:+d}) \u00b7 ')
                                st.caption(f'**{_r["name"]}** \u2014 ' + _slam_bit +
                                           f'HR Score {_r["hr_score"]} \u2192 '
                                           f'Edge {_r["edge"]} \u00b7 ' + " \u00b7 ".join(_parts))

                        # ---- Batter Trend: pick any batter in this lineup,
                        # see his real game-by-game results (official MLB
                        # box scores — the source that actually carries RBI
                        # and runs, which Statcast pitch data doesn't) ----
                        st.markdown(
                            f'<div class="pf-card-title" style="color:{COLOR["text"]}; margin-top:var(--lc-space-lg);">Batter Trend</div>'
                            f'<div class="pf-card-subtitle">Game-by-game Hits / HR / RBI / H+R+RBI from MLB official box scores.</div>',
                            unsafe_allow_html=True,
                        )
                        _bt_ids = {r["name"]: r["id"] for r in ranked if r.get("id")}
                        _bt_pick = st.selectbox(
                            "Batter trend",
                            ["Select a batter\u2026"] + list(_bt_ids.keys()),
                            key=f"bt_pick_{st.session_state['gc_selected_game_idx']}",
                            label_visibility="collapsed",
                        )
                        if _bt_pick in _bt_ids:
                            # ---- First-pitch tendency + switch-hitter sides ----
                            # A switch hitter's two sides are often different
                            # hitters; showing one blended number hides the
                            # split that decides the matchup, so both are
                            # offered whenever he actually bats both ways.
                            _bt_row = next((r for r in ranked if r["name"] == _bt_pick), {})
                            _bt_bats = (_bt_row.get("bats") or "").upper()
                            _side_opts = ["Combined", "as RHB", "as LHB"] if _bt_bats == "S" else ["Combined"]
                            _side_pick = "Combined"
                            if len(_side_opts) > 1:
                                _side_pick = st.segmented_control(
                                    "Batting side", _side_opts, default="Combined",
                                    key=f"bt_side_{st.session_state['gc_selected_game_idx']}",
                                    label_visibility="collapsed",
                                ) or "Combined"
                            _stand = {"as RHB": "R", "as LHB": "L"}.get(_side_pick)

                            _fp = get_first_pitch_swing(_bt_ids[_bt_pick],
                                                        window="season", stand=_stand)
                            if _fp.get("swing_pct") is not None:
                                _fp_col = (COLOR["error"] if _fp["swing_pct"] >= 40
                                           else COLOR["stat_high"] if _fp["swing_pct"] <= 20
                                           else COLOR["warn"])
                                _extra = []
                                if _fp.get("contact") is not None:
                                    _extra.append(f'{_fp["contact"]:.0f}% contact when he swings')
                                if _fp.get("hard_hit") is not None:
                                    _extra.append(f'{_fp["hard_hit"]:.0f}% hard-hit')
                                if _fp.get("xslg") is not None:
                                    _extra.append(f'{_fp["xslg"]:.3f} xSLG on first-pitch contact')
                                # NOTE: no backslash escapes inside f-string
                                # expressions — Python 3.11 (Render) rejects
                                # them even though 3.12 allows it.
                                _sep = " \u00b7 "
                                _side_txt = (_sep + _side_pick.lower()) if _stand else ""
                                _extra_txt = _sep.join(_extra)
                                _extra_html = (
                                    f'<div style="font-size:var(--lc-text-tiny); opacity:0.65; '
                                    f'margin-top:var(--lc-space-hair);">{_extra_txt}</div>'
                                ) if _extra else ""
                                st.markdown(
                                    f'<div style="font-family:\'JetBrains Mono\',monospace; '
                                    f'font-size:var(--lc-text-small); color:{COLOR["text"]}; margin:var(--lc-space-sm) var(--lc-space-none);">'
                                    f'First-pitch swing '
                                    f'<b style="color:{_fp_col};">{_fp["swing_pct"]:.1f}%</b> '
                                    f'<span style="opacity:0.6;">({_fp["pa"]} first pitches'
                                    f'{_side_txt})</span>'
                                    + _extra_html
                                    + '</div>',
                                    unsafe_allow_html=True,
                                )
                            elif _fp.get("reason"):
                                st.caption(f'First-pitch swing rate: {_fp["reason"]}.')

                            _bt_stat = st.segmented_control(
                                "Stat", ["Hits", "1B", "2B", "3B", "HR", "RBI",
                                         "Runs", "Total Bases", "Walks",
                                         "Strikeouts", "H+R+RBI"],
                                default="Hits", key="bt_stat", label_visibility="collapsed",
                            )
                            from datetime import datetime as _dtn
                            _yr = _dtn.now().year
                            _bt_win = st.segmented_control(
                                "Window", [str(_yr), str(_yr - 1), "H2H", "L25", "L15", "L10", "L5"],
                                default="L15", key="bt_window", label_visibility="collapsed",
                            )
                            # Line options follow the stat, and the key
                            # includes it so switching stats doesn't carry a
                            # stale line across (a 3.5 HR line is nonsense).
                            _BT_LINES = {
                                "Hits": (["0.5", "1.5", "2.5"], "0.5"),
                                "1B": (["0.5", "1.5"], "0.5"),
                                "2B": (["0.5", "1.5"], "0.5"),
                                "3B": (["0.5"], "0.5"),
                                "HR": (["0.5", "1.5"], "0.5"),
                                "RBI": (["0.5", "1.5", "2.5"], "0.5"),
                                "Runs": (["0.5", "1.5"], "0.5"),
                                "Total Bases": (["0.5", "1.5", "2.5", "3.5"], "1.5"),
                                "Walks": (["0.5", "1.5"], "0.5"),
                                "Strikeouts": (["0.5", "1.5", "2.5"], "0.5"),
                                "H+R+RBI": (["1.5", "2.5", "3.5", "4.5"], "2.5"),
                            }
                            _bt_opts, _bt_dflt = _BT_LINES.get(_bt_stat or "Hits",
                                                               (["0.5", "1.5"], "0.5"))
                            _bt_line = st.segmented_control(
                                "Line", _bt_opts, default=_bt_dflt,
                                key=f"bt_line_{_bt_stat or 'Hits'}",
                                label_visibility="collapsed",
                            )
                            # For H2H the opponent is the pitcher's team
                            # (the team this lineup is facing tonight).
                            _bt_opp_team = game["away"] if pitcher_choice.startswith(game["away_pitcher"]) else game["home"]
                            render_batter_trend(
                                _bt_ids[_bt_pick], _bt_pick,
                                _bt_stat or "Hits", _bt_win or "L15",
                                line=float(_bt_line or _bt_dflt),
                                opp_label=team_abbr(_bt_opp_team),
                            )
                            # ---- FORM, as its own component ----
                            #
                            # The lineup table above carries the two
                            # deltas as columns; this is the same
                            # measurement with its working shown — recent
                            # and season side by side, so the subtraction
                            # is checkable rather than asserted. One
                            # renderer (engines/form.render_form) draws it
                            # wherever it appears, which is the whole
                            # reason it is a component: the definition
                            # cannot drift between the board and the card.
                            #
                            # Season profile is refetched rather than
                            # taken off `ranked`, so this reads the same
                            # baseline the engine used even if the row
                            # was built on an earlier paint.
                            _fm_season = get_batter_profile_windowed(
                                _bt_ids[_bt_pick], window="season", unit="bbe")
                            _fm_recent = get_batter_profile_windowed(
                                _bt_ids[_bt_pick],
                                window=form_engine.FORM_WINDOW,
                                unit=form_engine.FORM_UNIT)
                            form_engine.render_form(
                                _fm_season, _fm_recent,
                                title=f"Form \u2014 {_bt_pick}")

                            # Deep dive: career BvP vs tonight's selected
                            # pitcher, then zone map + spray chart on the
                            # SAME window the trend chart is showing.
                            render_bvp_card(
                                _bt_ids[_bt_pick], _bt_pick,
                                pitcher_id, selected_pitcher_name,
                            )
                            _dd1, _dd2 = st.columns([1, 1.35])
                            with _dd1:
                                render_zone_map(_bt_ids[_bt_pick], _bt_pick,
                                                _bt_win or "L10")
                            with _dd2:
                                render_spray_chart(_bt_ids[_bt_pick], _bt_pick,
                                                   _bt_win or "L10",
                                                   wind=game.get("weather_wind"))

        if table_rows:
            top_3_pitches = [pt for pt, usage in sorted(arsenal.items(), key=lambda x: -x[1])[:3]] if arsenal else []
            with card("vs_top_pitches"):
                top_3_names = ", ".join(pitch_name(pt) for pt in top_3_pitches) if top_3_pitches else "unknown"
                st.markdown(
                    f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Vs {selected_pitcher_name}\'s Top 3 Pitches</div>'
                    f'<div class="pf-card-subtitle">Real per-batter performance specifically against {top_3_names} \u2014 same {window_choice} window as the Lineup table above</div>',
                    unsafe_allow_html=True,
                )
                if not top_3_pitches:
                    st.info("No real pitch arsenal data available for this pitcher yet \u2014 nothing to honestly compare batters against.")
                else:
                    # THE SAME WINDOW SETTING, REACHABLE FROM HERE.
                    #
                    # This table obeys the Window control at the top of
                    # the card, hundreds of pixels up past the lineup
                    # table. Reading it at a different window meant
                    # scrolling up, changing it, and hunting back down
                    # for your place — on a phone, most of a minute,
                    # every time.
                    #
                    # Not a second setting: _window_control writes the
                    # one shared value, so this and the top picker can
                    # never disagree. Changing it here reruns the card
                    # and the lineup table above moves with it.
                    _tp_l, _tp_r = st.columns([1, 2])
                    with _tp_l:
                        _window_control(
                            "lineup_window_top3",
                            help=("Shared with the Lineup table above \u2014 "
                                  "changing it here changes it there too, so "
                                  "the two can never show different windows."),
                        )
                    matchup_rows = []
                    for r in filtered:
                        vs_profile = get_batter_vs_pitch_types(r.get("id"), tuple(top_3_pitches), window=window_key, unit=unit_key)
                        pitches_seen = vs_profile.get("_pitches_seen", 0)
                        # BIP IS THE SECOND SAMPLE, AND IT IS THE ONE
                        # THAT MATTERS FOR FOUR OF THESE COLUMNS.
                        #
                        # Pitches Seen was the only sample shown, and it
                        # is the wrong denominator for Brl%, HH%, FB% and
                        # AvgEV — all four are per BALL IN PLAY. Against
                        # three pitch types in a recent window a hitter
                        # can easily see 60 pitches and put 9 of them in
                        # play, and a barrel rate off 9 batted balls is
                        # noise wearing a percentage sign. Pitches Seen
                        # 60 looks like a usable sample; BIP 9 says what
                        # it actually is.
                        #
                        # Whiff% stays governed by Pitches Seen, which is
                        # why both columns are here rather than one
                        # replacing the other.
                        _bip = vs_profile.get("BBE") or 0
                        matchup_rows.append({
                            "Player": r["name"],
                            "Bats": r["bats"],
                            "Pitches Seen": pitches_seen,
                            "BIP": _bip,
                            "xwOBA": vs_profile.get("xwOBA") if pitches_seen > 0 else None,
                            "ISO": vs_profile.get("ISO") if pitches_seen > 0 else None,
                            "Brl%": vs_profile.get("Brl %") if pitches_seen > 0 else None,
                            "HH%": vs_profile.get("HH %") if pitches_seen > 0 else None,
                            # FB% AND AvgEV — the two halves of a home-run
                            # ball, against the pitches he will actually
                            # see tonight.
                            #
                            # The lineup table above carries both, but for
                            # EVERYTHING he has faced. That is the wrong
                            # question here. A hitter who lifts the ball
                            # at 42% overall and 19% against sliders has a
                            # slider problem, and only this table can show
                            # it — the season number averages it away.
                            # Read as a pair: FB% is whether he gets it in
                            # the air off this stuff, AvgEV is whether
                            # there is anything behind it when he does.
                            # Neither alone is a power read (a 78 mph fly
                            # ball is an out; a 104 mph grounder is a
                            # single), which is exactly why HR Score
                            # weights their intersection and not either
                            # parent.
                            #
                            # Both gated on _bip, not pitches_seen: they
                            # are batted-ball measurements, so a row with
                            # pitches but no contact has genuinely not
                            # measured them and must stay blank rather
                            # than print whatever a zero-BBE division
                            # produced.
                            "FB%": vs_profile.get("FB %") if _bip > 0 else None,
                            "AvgEV": vs_profile.get("AvgEV") if _bip > 0 else None,
                            "Whiff%": vs_profile.get("Whiff %") if pitches_seen > 0 else None,
                            "Zone Fit": (f'{r["zone_adj"]:+d}' if r.get("zone_adj") else "\u2014"),
                            "BvP (career)": r.get("bvp_line") or "\u2014",
                        })
                    matchup_df = pd.DataFrame(matchup_rows)
                    render_html_table(
                        style_stat_table(
                            matchup_df,
                            # Pitches Seen and BIP are deliberately NOT
                            # graded. They are sample sizes, not skill:
                            # colouring 140 pitches green and 40 red would
                            # say the bat with more data is the better
                            # matchup, which is a different claim and a
                            # false one. They stay plain so they read as
                            # the qualifier they are.
                            favor_high=["xwOBA", "ISO", "Brl%", "HH%", "FB%",
                                        "AvgEV", "Zone Fit"],
                            favor_low=["Whiff%"], gradient=True).format(
                            {"xwOBA": "{:.3f}", "ISO": "{:.3f}", "Brl%": "{:.1f}",
                             "HH%": "{:.1f}", "Whiff%": "{:.1f}",
                             "FB%": "{:.1f}",
                             # mph, one decimal — how Statcast publishes
                             # exit velocity and how the lineup table
                             # above formats the same measurement.
                             "AvgEV": "{:.1f}",
                             # Counts, whole.
                             "Pitches Seen": "{:.0f}", "BIP": "{:.0f}"},
                            na_rep="\u2014"), key="gc_1809")
                    st.caption(
                        "\"Pitches Seen\" and \"BIP\" are the two real sample sizes behind each row, and they "
                        "govern different columns: Whiff% rests on pitches, while Brl%, HH%, FB% and AvgEV are "
                        "all per BALL IN PLAY. A low number in either is a real, honest small sample, not a "
                        "hidden flaw \u2014 60 pitches seen with 9 balls in play means the rates to the right are "
                        "off nine swings. Blank cells mean this batter hasn't faced any of these specific pitch "
                        "types in the selected window yet; a blank FB%/AvgEV beside a live Whiff% means he has "
                        "faced them and simply hasn't put one in play. FB% and AvgEV are the two halves of a "
                        "home-run ball against THIS arsenal \u2014 whether he gets it airborne, and whether there "
                        "is anything behind it \u2014 and either alone is not a power read. BvP (career) is his "
                        "real career line vs THIS starter (MLB official vs-player split) \u2014 the same history "
                        "that moves SLAM and the Matchup Edges tiers, per the tiers documented in engines/edge.py."
                    )

        if table_rows:
            # Full per-pitch-category profile: how each hitter does against
            # Fastballs / Breaking / Offspeed across the board (not just
            # tonight's arsenal). Grouped into three families rather than
            # every individual code, because a single hitter rarely has a
            # usable sample against, say, sweepers alone in a recent window.
            _PITCH_GROUPS = {
                "Fastballs": ("FF", "FA", "SI", "FC"),
                "Breaking": ("SL", "ST", "CU", "KC", "CS", "SV"),
                "Offspeed": ("CH", "FS", "FO", "EP"),
            }
            with card("vs_pitch_family"):
                st.markdown(
                    f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Batter vs Pitch Type</div>'
                    f'<div class="pf-card-subtitle">How one hitter performs against each pitch family \u2014 '
                    f'same {window_choice} window. Pick a batter.</div>',
                    unsafe_allow_html=True,
                )
                _names = [r["name"] for r in filtered]
                if _names:
                    _pick = st.selectbox("Batter", _names, key="vs_pitch_family_pick")
                    _row = next((r for r in filtered if r["name"] == _pick), None)
                    if _row is not None:
                        fam_rows = []
                        for fam_label, fam_codes in _PITCH_GROUPS.items():
                            vp = get_batter_vs_pitch_types(
                                _row.get("id"), fam_codes, window=window_key, unit=unit_key)
                            seen = vp.get("_pitches_seen", 0)
                            fam_rows.append({
                                "Pitch Type": fam_label,
                                "Pitches Seen": seen,
                                "BA": vp.get("BA") if seen > 0 else None,
                                "xwOBA": vp.get("xwOBA") if seen > 0 else None,
                                "xSLG": vp.get("xSLG") if seen > 0 else None,
                                "ISO": vp.get("ISO") if seen > 0 else None,
                                "Brl%": vp.get("Brl %") if seen > 0 else None,
                                "HH%": vp.get("HH %") if seen > 0 else None,
                                "Whiff%": vp.get("Whiff %") if seen > 0 else None,
                            })
                        fam_df = pd.DataFrame(fam_rows)
                        render_html_table(
                            style_stat_table(
                                fam_df, favor_high=["BA", "xwOBA", "xSLG", "ISO", "Brl%", "HH%"],
                                favor_low=["Whiff%"], gradient=True,
                            ).format(
                                {"BA": "{:.3f}", "xwOBA": "{:.3f}", "xSLG": "{:.3f}", "ISO": "{:.3f}",
                                 "Brl%": "{:.1f}", "HH%": "{:.1f}", "Whiff%": "{:.1f}"},
                                na_rep="\u2014",
                            ), key="gc_1862")
                        st.caption(
                            "Fastballs = 4-seam, sinker, cutter. Breaking = slider, sweeper, curve, "
                            "knuckle-curve, slurve. Offspeed = changeup, splitter, forkball. "
                            "\"Pitches Seen\" is the real sample \u2014 blank rows mean he hasn't faced "
                            "that family in this window. A hitter strong vs one family and weak vs "
                            "another is a matchup edge once you know what the starter throws most."
                        )

        if table_rows:
            with card("matchup_edges"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Matchup Edges</div>', unsafe_allow_html=True)

                tier_order = [
                    ("strong", "Strong Targets"),
                    ("good", "Good Picks"),
                    ("neutral", "Neutral"),
                    ("risk", "Risk / Avoid"),
                ]
                for tier_key, tier_label in tier_order:
                    tier_rows = [r for r in table_rows if r["EdgeTier"] == tier_key]
                    if not tier_rows:
                        continue
                    st.markdown(
                        f'<div style="margin:var(--lc-space-md) var(--lc-space-none) var(--lc-space-sm) var(--lc-space-none);">{edge_tag(f"{tier_label} ({len(tier_rows)})", tier_key)}</div>',
                        unsafe_allow_html=True,
                    )
                    tier_df = pd.DataFrame([
                        {"Player": r["Player"], "Bats": r["Bats"], "Detail": r["EdgeLabel"], "Confidence": r["Confidence"]}
                        for r in tier_rows
                    ])
                    render_html_table(plain_dark_table(tier_df), key="gc_1903")

        tab_arsenal, tab_scout = st.tabs(["Pitch Arsenal", "\U0001F52D Scout Report"])
        with tab_arsenal:
            with card("pitch_arsenal_tab"):
                st.markdown(
                    f'<div class="pf-card-title" style="color:{COLOR["gold"]};">Pitch Arsenal</div>'
                    f'<div class="pf-card-subtitle" style="color:{COLOR["text_muted"]};">What each pitch actually does, not just how often it\'s thrown</div>',
                    unsafe_allow_html=True,
                )
                arsenal_detail = pitcher_data.get("Pitch Arsenal Detail", {}) if pitcher_data else {}
                if not arsenal_detail:
                    st.info("No pitch-level data available for this pitcher yet.")
                else:
                    sorted_pitches = sorted(arsenal_detail.items(), key=lambda x: -x[1]["usage"])
                    for pt, d in sorted_pitches:
                        c = pitch_color(pt)
                        whiff_display = f"{d['whiff']:.1f}%" if d["whiff"] is not None else "N/A"
                        hh_display = f"{d['hh_allowed']:.1f}%" if d["hh_allowed"] is not None else "N/A"
                        st.markdown(
                            f'<div style="margin-bottom:var(--lc-space-lg);">'
                            f'<div style="display:flex; justify-content:space-between; align-items:baseline; margin-bottom:var(--lc-space-xs);">'
                            f'<span style="font-weight:700; color:{c}; font-size:var(--lc-text-body-lg);">{pitch_name(pt)}</span>'
                            f'<span style="font-family:\'JetBrains Mono\',monospace; color:{COLOR["text_muted"]}; font-size:var(--lc-text-small);">n={d["n"]}</span>'
                            f'</div>'
                            f'<div style="height:8px; width:100%; background:{COLOR["surface_raised"]}; border-radius:var(--lc-radius-sm); margin-bottom:var(--lc-space-sm);">'
                            f'<div style="height:8px; width:{min(d["usage"],100)}%; background:{c}; border-radius:var(--lc-radius-sm);"></div>'
                            f'</div>'
                            f'<div style="display:flex; gap:18px; font-size:var(--lc-text-small); font-family:\'JetBrains Mono\',monospace;">'
                            f'<span style="color:{COLOR["text_muted"]};">Usage <b style="color:{COLOR["text"]};">{d["usage"]:.1f}%</b></span>'
                            f'<span style="color:{COLOR["text_muted"]};">Whiff <b style="color:{COLOR["stat_high"] if (d["whiff"] or 0) >= 25 else COLOR["text"]};">{whiff_display}</b></span>'
                            f'<span style="color:{COLOR["text_muted"]};">Hard-Hit Allowed <b style="color:{COLOR["error"] if (d["hh_allowed"] or 0) >= 40 else COLOR["text"]};">{hh_display}</b></span>'
                            f'</div>'
                            f'</div>',
                            unsafe_allow_html=True,
                        )
                    st.caption("Whiff% / Hard-Hit% are real, computed per pitch type from this pitcher's own raw Statcast data \u2014 not league averages.")

        with tab_scout:
            st.markdown(
                f'<div class="pf-card-title">Scout Report</div>'
                f'<div class="pf-card-subtitle">Pull any team\'s roster \u2014 not just today\'s matchups. Get ahead of tomorrow\'s opponent before anyone else does.</div>',
                unsafe_allow_html=True,
            )
            all_teams = get_all_teams()
            if not all_teams:
                st.warning("Couldn't load the team list from the MLB Stats API right now.")
            else:
                with card("scout_controls"):
                    sel_col, refresh_col = st.columns([4, 1])
                    with sel_col:
                        lookup_team = st.selectbox("Team", all_teams, key="scout_team_lookup")
                    with refresh_col:
                        st.markdown('<div style="height:28px;"></div>', unsafe_allow_html=True)
                        if st.button("\U0001F504 Refresh", key="scout_refresh", help="Forces a fresh pull instead of the cached roster (cached up to 30 min) \u2014 use this right before first pitch for the most current confirmed roster."):
                            get_live_team_roster.clear()
                            st.session_state["scout_fetch_time"] = datetime.now(EASTERN).strftime("%-I:%M:%S %p ET")
                            st.rerun()

                    if "scout_fetch_time" not in st.session_state:
                        st.session_state["scout_fetch_time"] = datetime.now(EASTERN).strftime("%-I:%M:%S %p ET")

                    st.caption(f"Roster as of {st.session_state['scout_fetch_time']} \u2014 auto-refreshes every 30 min, or hit Refresh for the latest right now.")

                    lookup_roster = get_live_team_roster(lookup_team)
                    if lookup_roster:
                        pitchers = [p for p in lookup_roster if p.get("is_pitcher")]
                        hitters = [p for p in lookup_roster if not p.get("is_pitcher")]

                        st.markdown(
                            badge(f"{len(lookup_roster)} Total", "neutral")
                            + badge(f"{len(pitchers)} Pitchers", "accent")
                            + badge(f"{len(hitters)} Position Players", "good"),
                            unsafe_allow_html=True,
                        )

                if lookup_roster:
                    with card("scout_position_players"):
                        st.markdown('<div class="pf-card-title">Position Players</div>', unsafe_allow_html=True)
                        if hitters:
                            hitters_df = pd.DataFrame(hitters)[["name", "position", "bats", "throws"]]
                            hitters_df.columns = ["Name", "Pos", "Bats", "Throws"]
                            render_html_table(plain_dark_table(hitters_df), key="gc_1985")
                        else:
                            st.caption("No position players found.")

                    with card("scout_pitchers"):
                        st.markdown('<div class="pf-card-title">Pitchers</div>', unsafe_allow_html=True)
                        if pitchers:
                            pitchers_df = pd.DataFrame(pitchers)[["name", "position", "bats", "throws"]]
                            pitchers_df.columns = ["Name", "Pos", "Bats", "Throws"]
                            render_html_table(plain_dark_table(pitchers_df), key="gc_1994")
                        else:
                            st.caption("No pitchers found.")
                else:
                    st.info(f"No roster data available for {lookup_team} right now.")

        # -------------------------------------------------
        # AI MATCHUP SUMMARY / KEY INSIGHTS / LEGEND
        # (template-generated from real numbers, no live LLM call)
        # -------------------------------------------------
        s1, s2, s3 = st.columns(3)
        with s1:
            with card("matchup_summary"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["text"]};">Matchup Summary</div>', unsafe_allow_html=True)
                top_arsenal = ", ".join(pitch_name(k) for k, v in sorted(arsenal.items(), key=lambda x: -x[1])[:2]) if arsenal else "an unclear arsenal"
                top_hr_names = ", ".join(r["name"] for r in sorted(ranked, key=lambda x: _score_sort_key(x, "hr_score"))[:2]) if ranked else "the lineup"
                st.markdown(
                    f'<span style="color:{COLOR["text_muted"]};">'
                    f"{selected_pitcher_name} relies heavily on {top_arsenal}. "
                    f"{top_hr_names} rate highest on HR Score against this arsenal. "
                    f"These are this app's own composite scores, not a certified prediction."
                    f'</span>',
                    unsafe_allow_html=True,
                )
        with s2:
            with card("key_insights"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["text"]};">Key Insights</div>', unsafe_allow_html=True)
                above_avg_hr = sum(1 for r in ranked if r["hr_score"] is not None and r["hr_score"] >= 60)
                high_k_risk = sum(1 for r in ranked if r["k_score"] is not None and r["k_score"] >= 70)
                st.markdown(f'<span style="color:{COLOR["text_muted"]};">\u2713 {above_avg_hr} batters with above-average HR Score</span>', unsafe_allow_html=True)
                st.markdown(f'<span style="color:{COLOR["text_muted"]};">\u2713 {high_k_risk} batters carrying elevated strikeout risk</span>', unsafe_allow_html=True)
                if park["verified"]:
                    st.markdown(f'<span style="color:{COLOR["text_muted"]};">\u2713 {park["venue"]} park factor: {park["park_factor"]}</span>', unsafe_allow_html=True)
        with s3:
            with card("legend"):
                st.markdown(f'<div class="pf-card-title" style="color:{COLOR["text"]};">Legend</div>', unsafe_allow_html=True)
                st.markdown(
                    edge_tag("Strong Edge", "strong") + " " + edge_tag("Good Pick", "good") + "<br><br>"
                    + edge_tag("Neutral", "neutral") + " " + edge_tag("Risk / Avoid", "risk"),
                    unsafe_allow_html=True,
                )

    footer()
