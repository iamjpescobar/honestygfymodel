"""NFL — Touchdown Board.

Who is most likely to reach the end zone this week, and WHY, with the
why on the row: how often he has scored, how many touches and targets he
gets, what the defense across from him allows, how often that defense
gives up a red-zone touchdown, and what the market thinks the game will
total.

There is deliberately NO composite score. One number would hide which
input is carrying it, and after week 1 every input rests on a single
game — a score built on that would look far more certain than it is
(standing rule 1: measure before setting any number).
"""
from datetime import datetime

import pandas as pd
import streamlit as st

from styles.kc_theme import (page_header, badge, footer, card, how_to_read,
                             COLOR, SPORT_ACCENTS)
from styles.table_style import style_stat_table
from engines.nfl_week import (EASTERN, load_week, staleness_note, td_rows,
                              td_reason)

_ACCENT = SPORT_ACCENTS.get("NFL") or COLOR["stat_high"]

page_header("NFL Touchdown Board", "Who scores, and the five numbers behind it",
            eyebrow="SCORING", align="left")


@st.cache_data(ttl=900, show_spinner=False)
def _load_week_for(day):
    return load_week()


_ROLES = {"Everyone": ("QB", "RB", "REC"), "Running backs": ("RB",),
          "Pass catchers": ("REC",), "Quarterbacks": ("QB",)}
_WINDOWS = {"Season": "season", "Last 3": "l3"}

_today = datetime.now(EASTERN).date()
payload, state = _load_week_for(_today.isoformat())

if state != "current":
    st.info(staleness_note(payload or {}, state, _today))
else:
    games = payload.get("games") or []
    how_to_read([
        ("TD/G", "Rushing plus receiving touchdowns per game, from real box "
                 "scores. A passing touchdown is the SAME scoreboard play as "
                 "the receiver's, so it is kept in its own column instead of "
                 "being counted twice."),
        ("Scored in %", "The share of his games with at least one touchdown. "
                        "A COUNT of what happened, not a probability of what will."),
        ("Opps/G", "Carries plus targets per game. Volume is the part of "
                   "scoring that repeats week to week, which is why it breaks ties here."),
        ("Opp TD allowed / rank", "Touchdowns that defense gives up per game, "
                                  "and its rank of 32 \u2014 a HIGH rank number means a soft defense."),
        ("Opp RZ TD %", "How often opponents score a touchdown, rather than "
                        "settling for a field goal, once inside the 20 against them."),
        ("Game O/U", "The posted total for that game, as ESPN lists it. More "
                     "expected points means more expected touchdowns to go round."),
        ("What this is not", "Not a pick and not a projection. Five measured "
                             "inputs, side by side, so you can see which ones agree."),
    ])

    c1, c2, c3 = st.columns([3, 2, 2])
    with c1:
        role_lab = st.segmented_control("Group", list(_ROLES), default="Everyone",
                                        key="nfl_td_role", label_visibility="collapsed")
    with c2:
        win_lab = st.segmented_control("Window", list(_WINDOWS), default="Season",
                                       key="nfl_td_win", label_visibility="collapsed")
    with c3:
        hide_final = st.toggle("Hide games already final", value=True, key="nfl_td_final")

    rows = td_rows(games, _WINDOWS.get(win_lab or "Season", "season"),
                   _ROLES.get(role_lab or "Everyone", ("QB", "RB", "REC")))
    if hide_final:
        rows = [r for r in rows if not r["final"]]

    if not rows:
        st.info("No scoring samples yet \u2014 the board fills in after each "
                "team's first final.")
    else:
        st.markdown(
            f'<div style="color:{_ACCENT}; font-weight:800; letter-spacing:0.12em; '
            f'text-transform:uppercase; font-size:var(--lc-text-caption); '
            f'margin:var(--lc-space-lg) 0 var(--lc-space-sm);">Top of the board</div>',
            unsafe_allow_html=True)
        for r in rows[:5]:
            with card(f'nfl_td_{r["Player"]}'):
                st.markdown(
                    f'<div style="font-weight:800; font-size:var(--lc-text-body-lg);">'
                    f'{r["Player"]} <span style="color:{COLOR["text_faint"]}; '
                    f'font-size:var(--lc-text-tiny);">{r["Pos"]} \u00b7 {r["Team"]} '
                    f'vs {r["Opp"]} \u00b7 {r["Window"]}</span></div>'
                    f'<div style="color:{COLOR["text_muted"]}; font-size:var(--lc-text-small); '
                    f'line-height:1.7;">{td_reason(r)}</div>', unsafe_allow_html=True)
                if r.get("Status"):
                    st.markdown(badge(r["Status"], "bad"), unsafe_allow_html=True)

        df = pd.DataFrame([{k: v for k, v in r.items() if k not in ("final", "Window")}
                           for r in rows])
        sty = style_stat_table(
            df, favor_high=["TD/G", "Scored in %", "Opps/G", "Pass TD/G",
                            "Opp TD allowed", "Opp TD rank", "Opp RZ TD %", "Game O/U"],
            gradient=False)
        sty = sty.format({"TD/G": "{:.2f}", "Pass TD/G": "{:.2f}", "Opps/G": "{:.1f}",
                          "Scored in %": "{:.0f}%", "Opp TD allowed": "{:.1f}",
                          "Opp RZ TD %": "{:.0f}%", "Opp TD rank": "{:.0f}",
                          "Game O/U": "{:g}", "GP": "{:.0f}"}, na_rep="\u2014")
        st.dataframe(sty, hide_index=True, width="stretch")
        st.caption("Sorted by touchdowns per game, then by opportunities. Brighter "
                   "= more of that thing, including a softer defense. Research, not "
                   "a pick.")
    st.caption(f'Built {payload.get("generated_at_et")} ET from '
               f'{payload.get("finals_parsed", 0)} real box scores.')

footer()
