"""
Book prop lines snapshot (10-23) — every nightly run saves the
sportsbook's player-prop lines and prices (engines/book_props, ESPN's
free core feed, DraftKings) for every game in the next day and a half
(NFL: the coming week), to data/props/{league}/{date}.json in the repo,
committed by its own workflow step: a record that only exists if it is
saved the day it is posted.

Each run MERGES into the day's file: the first price seen is kept next
to the latest one (the 6 PM ET run is the closest to puck drop / tip).

What it is for: (1) the boards open on the book's line and price, (2)
every disagreement between the site's chance and the book's is graded
after the games — whether the site beats the book, market by market.
Neither is built yet; this is the record they need.

Prints [verify] lines: events, items, which of a pair is the over
(side_check, measured against the milestones), per-type counts.
Never fails the nightly: one league down costs that league's file.
"""
import json
import sys
import time
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "app"))
from engines import book_grade as bg  # noqa: E402
from engines import book_props as bp  # noqa: E402

OUT = ROOT / "data" / "props"
PAYLOADS = ROOT / "build_data" / "data"          # tonight's games.json per league
LEAGUES = {"nhl": 2, "nba": 2, "mlb": 2, "nfl": 7}     # days ahead to look


def upcoming(league, today, days, fetch_scoreboard):
    """{event_id: (date iso, label)} — games not yet started."""
    out = {}
    for k in range(days):
        d = today + timedelta(days=k)
        try:
            sb, _src = fetch_scoreboard(league, d.strftime("%Y%m%d"))
        except Exception as exc:  # noqa: BLE001
            print(f"  {league}: scoreboard {d} failed: {exc}")
            continue
        for ev in sb.get("events") or []:
            st = (((ev.get("status") or {}).get("type") or {}).get("state")) or ""
            if st == "pre":
                out[str(ev.get("id"))] = (d.isoformat(), ev.get("shortName") or ev.get("name"))
    return out


def run_league(league, today, get, fetch_scoreboard, sport_lg, out_dir=OUT, now=None,
               sleep=0.1, payload_dir=None):
    sport, lg = sport_lg
    evs = upcoming(league, today, LEAGUES.get(league, 2), fetch_scoreboard)
    by_date, types, n_items = {}, Counter(), 0
    ev_names = {}
    all_rows = []
    for eid, (d, _lab) in evs.items():
        try:
            items = bp.fetch_event(get, sport, lg, eid)
        except Exception as exc:  # noqa: BLE001
            print(f"  {league}: props for {eid} failed: {type(exc).__name__}: {exc}")
            continue
        rows = bp.parse(items)
        if league == "mlb":
            # ESPN's MLB ids are not MLBAM's: keep each player's NAME with the
            # record so the pages can match him (one athlete call each, once)
            path = Path(out_dir) / league / f"{d}.json"
            known = ((json.loads(path.read_text()).get(eid) or {}).get("names")
                     if path.exists() else None) or {}
            ev_names[eid] = dict(known, **bp.athlete_names(get, rows, known))
        n_items += len(rows)
        types.update(r["type"] for r in rows)
        all_rows += rows
        by_date.setdefault(d, {})[eid] = rows
        time.sleep(sleep)
    sc = bp.side_check(all_rows)
    now = now or datetime.utcnow().strftime("%Y-%m-%dT%H:%MZ")
    written = []
    for d, ev_rows in by_date.items():
        path = Path(out_dir) / league / f"{d}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        old = json.loads(path.read_text()) if path.exists() else {}
        path.write_text(json.dumps(bp.merge_snapshot(old, ev_rows, now, ev_names),
                                   separators=(",", ":")))
        written.append(path.name)
    # THE SITE'S CHANCES at those same lines, saved beside them (book_grade
    # step 1) — tonight's payload, built by this run's league step
    n_ours = 0
    if league in bg.ROWS and payload_dir is not None:
        try:
            pl = json.loads((Path(payload_dir) / league / "games.json").read_text())
            files = [json.loads((Path(out_dir) / league / f"{d}.json").read_text())
                     for d in by_date]
            ours = bg.capture(league, pl, bp.board(files))
            for d in by_date:
                path = Path(out_dir) / league / f"{d}.json"
                js = json.loads(path.read_text())
                for eid in js:
                    if eid in ours and eid in evs:
                        js[eid]["ours"], js[eid]["ours_at"] = ours[eid], now
                        n_ours += len(ours[eid])
                path.write_text(json.dumps(js, separators=(",", ":")))
        except Exception as exc:  # noqa: BLE001 — costs the capture, never the lines
            print(f"::warning::book props {league}: the site's chances not saved: "
                  f"{type(exc).__name__}: {exc}")
        print(f"  [verify] BOOK PROPS {league}: the site's chance saved at {n_ours} book lines "
              f"(graded after the games)")
    n_saved = sum(len(v) for v in by_date.values())
    if ev_names:
        print(f"  [verify] BOOK PROPS {league}: player names kept for "
              f"{sum(len(v) for v in ev_names.values())} players (pages match MLB by name)")
    print(f"  [verify] BOOK PROPS {league}: {len(evs)} upcoming events, {n_saved} with props "
          f"saved; {n_items} prop items -> {written}")
    print(f"  [verify] BOOK PROPS {league}: which of a pair is the over, measured against the "
          f"milestones: {sc}")
    print(f"  [verify] BOOK PROPS {league}: types {dict(types.most_common(14))}")
    return {"events": len(evs), "items": n_items, "side": sc, "files": written}


# 10-26: the day files grow ~1.5 MB a day across the leagues and every run
# rewrites today's; the grade keeps what it needs in data/props/graded
# (one compact row per line, with our chance, the book's and the result).
# A day file is dropped once it is KEEP_DAYS old and nothing in it is still
# waiting to be graded, and at HARD_DAYS old whatever it holds (a game
# that never finished). Pages read only today's and the coming days'.
KEEP_DAYS = 14
HARD_DAYS = 30


def prune(out_dir, today, keep_days=KEEP_DAYS, hard_days=HARD_DAYS):
    """[paths removed] — day files past their keep."""
    gone = []
    for lg_dir in sorted(Path(out_dir).iterdir()) if Path(out_dir).exists() else []:
        if not lg_dir.is_dir() or lg_dir.name == "graded":
            continue
        for f in sorted(lg_dir.glob("*.json")):
            try:
                d = datetime.strptime(f.stem, "%Y-%m-%d").date()
            except ValueError:
                continue
            age = (today - d).days
            if age < keep_days:
                continue
            if age < hard_days:
                try:
                    js = json.loads(f.read_text())
                except Exception:  # noqa: BLE001
                    continue
                waiting = [e for e in js.values() if isinstance(e, dict) and e.get("ours")
                           and e.get("graded") is None]
                if waiting:
                    continue
            f.unlink()
            gone.append(f"{lg_dir.name}/{f.name}")
    return gone


def main():
    from engines import espn_feed as ef
    from zoneinfo import ZoneInfo
    today = datetime.now(ZoneInfo("America/New_York")).date()
    for lg in LEAGUES:
        try:
            run_league(lg, today, ef.get_json, ef.fetch_scoreboard, ef.LEAGUES[lg],
                       payload_dir=PAYLOADS)
        except Exception as exc:  # noqa: BLE001
            print(f"::warning::book props {lg} failed: {type(exc).__name__}: {exc}")
    gone = prune(OUT, today)
    print(f"  [verify] BOOK PROPS: {len(gone)} day files past {KEEP_DAYS} days removed "
          f"(graded rows stay in data/props/graded) {gone[:6]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
